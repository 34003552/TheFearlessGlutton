package emptyfield.thefearlessglutton.Configurations;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Un paramétrage de jeu décrivant la version originale
 */
public class GameConfigClassic extends GameConfig {

    /**
     * Définit un paramétrage de jeu décrivant la version originale
     */
    public GameConfigClassic() {
        // définit la vitesse et les dimensions de la grille
        super(250, 26, 29);
        // définit la matrice des murs horizontaux
        mHWalls = new boolean[][]{
                {true, true, true, true, true, true, true, true, true, true, true, true, false, false, true, true, true, true, true, true, true, true, true, true, true, true},
                {false, true, true, true, true, false, true, true, true, true, true, false, false, false, false, true, true, true, true, true, false, true, true, true, true, false},
                {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
                {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
                {false, true, true, true, true, false, true, true, true, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false},
                {false, true, true, true, true, false, true, true, false, true, true, true, true, true, true, true, true, false, true, true, false, true, true, true, true, false},
                {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
                {false, true, true, true, true, false, false, false, false, true, true, true, false, false, true, true, true, false, false, false, false, true, true, true, true, false},
                {true, true, true, true, true, false, false, false, true, true, true, false, false, false, false, true, true, true, false, false, false, true, true, true, true, true},
                {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
                {false, false, false, false, false, false, false, false, true, true, true, false, true, true, false, true, true, true, false, false, false, false, false, false, false, false},
                {false, false, false, false, false, false, false, false, false, true, true, true, false, false, true, true, true, false, false, false, false, false, false, false, false, false},
                {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
                {true, true, true, true, true, false, true, true, false, false, false, false, false, false, false, false, false, false, true, true, false, true, true, true, true, true},
                {true, true, true, true, true, false, true, true, false, false, false, false, false, false, false, false, false, false, true, true, false, true, true, true, true, true},
                {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
                {false, false, false, false, false, false, false, false, false, true, true, true, true, true, true, true, true, false, false, false, false, false, false, false, false, false},
                {false, false, false, false, false, false, false, false, false, true, true, true, true, true, true, true, true, false, false, false, false, false, false, false, false, false},
                {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
                {true, true, true, true, true, false, true, true, false, true, true, true, false, false, true, true, true, false, true, true, false, true, true, true, true, true},
                {false, true, true, true, true, false, true, true, true, true, true, false, false, false, false, true, true, true, true, true, false, true, true, true, true, false},
                {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
                {false, true, true, false, false, false, true, true, true, true, true, false, true, true, false, true, true, true, true, true, false, false, false, true, true, false},
                {true, true, false, false, false, false, true, true, false, true, true, true, true, true, true, true, true, false, true, true, false, false, false, false, true, true},
                {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
                {true, true, false, true, true, false, false, false, false, true, true, true, false, false, true, true, true, false, false, false, false, true, true, false, true, true},
                {false, true, true, true, true, true, false, false, true, true, true, false, false, false, false, true, true, true, false, false, true, true, true, true, true, false},
                {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
                {false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false},
                {true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true}
        };
        // définit la matrice des murs verticaux
        mVWalls = new boolean[][]{
                {true, false, false, false, false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, false, false, false, false, false, true},
                {true, true, false, false, false, true, true, false, false, false, false, true, true, false, true, true, false, false, false, false, true, true, false, false, false, true, true},
                {true, true, false, false, false, true, true, false, false, false, false, true, true, false, true, true, false, false, false, false, true, true, false, false, false, true, true},
                {true, true, false, false, false, true, true, false, false, false, false, true, true, false, true, true, false, false, false, false, true, true, false, false, false, true, true},
                {true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true},
                {true, true, false, false, false, true, true, false, true, true, false, false, false, false, false, false, false, true, true, false, true, true, false, false, false, true, true},
                {true, true, false, false, false, true, true, false, true, true, false, false, false, false, false, false, false, true, true, false, true, true, false, false, false, true, true},
                {true, false, false, false, false, false, true, false, true, false, false, false, true, false, true, false, false, false, true, false, true, false, false, false, false, false, true},
                {false, false, false, false, false, true, true, false, false, false, false, true, true, false, true, true, false, false, false, false, true, true, false, false, false, false, false},
                {false, false, false, false, false, true, true, false, false, false, false, true, true, false, true, true, false, false, false, false, true, true, false, false, false, false, false},
                {false, false, false, false, false, true, true, false, true, false, false, false, false, false, false, false, false, false, true, false, true, true, false, false, false, false, false},
                {false, false, false, false, false, true, true, false, true, true, false, false, false, false, false, false, false, true, true, false, true, true, false, false, false, false, false},
                {false, false, false, false, false, true, true, false, true, true, false, false, false, false, false, false, false, true, true, false, true, true, false, false, false, false, false},
                {false, false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false},
                {false, false, false, false, false, true, true, false, true, true, false, false, false, false, false, false, false, true, true, false, true, true, false, false, false, false, false},
                {false, false, false, false, false, true, true, false, true, true, false, false, false, false, false, false, false, true, true, false, true, true, false, false, false, false, false},
                {false, false, false, false, false, true, true, false, true, false, false, false, false, false, false, false, false, false, true, false, true, true, false, false, false, false, false},
                {false, false, false, false, false, true, true, false, true, true, false, false, false, false, false, false, false, true, true, false, true, true, false, false, false, false, false},
                {false, false, false, false, false, true, true, false, true, true, false, false, false, false, false, false, false, true, true, false, true, true, false, false, false, false, false},
                {true, false, false, false, false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, false, false, false, false, false, true},
                {true, true, false, false, false, true, true, false, false, false, false, true, true, false, true, true, false, false, false, false, true, true, false, false, false, true, true},
                {true, true, false, false, false, true, true, false, false, false, false, true, true, false, true, true, false, false, false, false, true, true, false, false, false, true, true},
                {true, false, false, true, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, true, false, false, true},
                {false, false, true, true, false, true, true, false, true, true, false, false, false, false, false, false, false, true, true, false, true, true, false, true, true, false, false},
                {false, false, true, true, false, true, true, false, true, true, false, false, false, false, false, false, false, true, true, false, true, true, false, true, true, false, false},
                {true, false, false, false, false, false, true, false, true, false, false, false, true, false, true, false, false, false, true, false, true, false, false, false, false, false, true},
                {true, true, false, false, false, false, false, false, false, false, false, true, true, false, true, true, false, false, false, false, false, false, false, false, false, true, true},
                {true, true, false, false, false, false, false, false, false, false, false, true, true, false, true, true, false, false, false, false, false, false, false, false, false, true, true},
                {true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true}
        };
        // définit la matrice des cases où peuvent se trouver des consommables
        mConsumableBoxes = new boolean[][]{
                {true, true, true, true, true, true, true, true, true, true, true, true, false, false, true, true, true, true, true, true, true, true, true, true, true, true},
                {true, false, false, false, false, true, false, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false, false, false, false, true},
                {true, false, false, false, false, true, false, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false, false, false, false, true},
                {true, false, false, false, false, true, false, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false, false, false, false, true},
                {true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true},
                {true, false, false, false, false, true, false, false, true, false, false, false, false, false, false, false, false, true, false, false, true, false, false, false, false, true},
                {true, false, false, false, false, true, false, false, true, false, false, false, false, false, false, false, false, true, false, false, true, false, false, false, false, true},
                {true, true, true, true, true, true, false, false, true, true, true, true, false, false, true, true, true, true, false, false, true, true, true, true, true, true},
                {false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
                {false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
                {false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
                {false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
                {false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
                {false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
                {false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
                {false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
                {false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
                {false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
                {false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
                {true, true, true, true, true, true, true, true, true, true, true, true, false, false, true, true, true, true, true, true, true, true, true, true, true, true},
                {true, false, false, false, false, true, false, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false, false, false, false, true},
                {true, false, false, false, false, true, false, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false, false, false, false, true},
                {true, true, true, false, false, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, false, false, true, true, true},
                {false, false, true, false, false, true, false, false, true, false, false, false, false, false, false, false, false, true, false, false, true, false, false, true, false, false},
                {false, false, true, false, false, true, false, false, true, false, false, false, false, false, false, false, false, true, false, false, true, false, false, true, false, false},
                {true, true, true, true, true, true, false, false, true, true, true, true, false, false, true, true, true, true, false, false, true, true, true, true, true, true},
                {true, false, false, false, false, false, false, false, false, false, false, true, false, false, true, false, false, false, false, false, false, false, false, false, false, true},
                {true, false, false, false, false, false, false, false, false, false, false, true, false, false, true, false, false, false, false, false, false, false, false, false, false, true},
                {true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true}
        };
        // définit la position initiale du joueur
        mLocationPlayer = new GridPoint(12, 22);
        // définit la position initiale de Blinky
        mLocationBlinky = new GridPoint(12, 10);
        // définit la position initiale de Pinky
        mLocationPinky = new GridPoint(10, 13);
        // définit la position initiale de Inky
        mLocationInky = new GridPoint(12, 13);
        // définit la position initiale de Clyde
        mLocationClyde = new GridPoint(14, 13);
        // définit la position des super pac-gommes
        mLocationBigGums = new GridPoint[]{
                new GridPoint(0, 2),
                new GridPoint(25, 2),
                new GridPoint(0, 22),
                new GridPoint(25, 22)
        };
        // définit les positions possibles pour les bonus
        mLocationExtras = new GridPoint[]{
                new GridPoint(12, 16)
        };
    }
}

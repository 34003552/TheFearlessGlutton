package emptyfield.thefearlessglutton.Consumables;

import android.graphics.Bitmap;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Une cloche définie comme étant un consommable
 */
public class Bell extends Consumable {

    /**
     * Construit une cloche
     * @param location la position de la cloche
     * @param skin l'apparence de la cloche
     */
    public Bell(GridPoint location, Bitmap skin) {
        super(location, skin, "bell", 3000);
    }
}

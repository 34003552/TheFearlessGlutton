package emptyfield.thefearlessglutton.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Set;
import java.util.TreeSet;

/**
 * L'activité hébergeant le menu de fin de partie
 */
public class GameOverActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher {
    private Button buttonSaveScore, buttonMainMenu;
    private EditText editTextUsername;
    private TextView textSaved;
    private String mNickname;

    /**
     * La méthode appelée lors de la création de l'activité
     * @param savedInstanceState le paramètre savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        buttonSaveScore = findViewById(R.id.buttonSaveScore);
        buttonMainMenu = findViewById(R.id.buttonMainMenu);
        editTextUsername = findViewById(R.id.editTextUsername);
        textSaved = findViewById(R.id.textSaved);

        buttonSaveScore.setOnClickListener(this);
        buttonMainMenu.setOnClickListener(this);
        editTextUsername.addTextChangedListener(this);
    }

    /**
     * Sauvegarde le score
     */
    public void saveScore() {
        // récupère la liste des scores
        SharedPreferences settings1 = getSharedPreferences("GameLists", 0);
        Set<String> scores = new TreeSet<>(settings1.getStringSet("scores", new TreeSet<String>()));
        // récupère le score courant
        SharedPreferences settings2 = getSharedPreferences("GameContext\n", 0);
        int currentScore = settings2.getInt("score",0);
        // récupère la date et l'heure courante
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Calendar calendar = Calendar.getInstance();
        // ajoute un score à la liste des scores selon le format 'score\nnickname\ndate'
        scores.add(currentScore+"\n"+mNickname+"\n"+sdf.format(calendar.getTime()));
        // redéfinit la liste des scores
        SharedPreferences.Editor editor = settings1.edit();
        editor.putStringSet("scores", scores);
        editor.apply();
    }

    /**
     * La méthode appelée lors d'un clic sur un bouton
     * @param view le paramètre view
     */
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.buttonSaveScore:
                // sauvegarde le score
                saveScore();
                // confirme la sauvegarde du score
                textSaved.setVisibility(View.VISIBLE);
                break;
            case R.id.buttonMainMenu:
                Intent intent1 = new Intent(GameOverActivity.this, MainMenuActivity.class);
                // démarre l'activité MainMenuActivity
                startActivity(intent1);
                break;
        }
    }

    /**
     * La méthode appelée avant le changement d'une entrée texte
     * @param s le paramètre s
     * @param start le paramètre start
     * @param count le paramètre count
     * @param after le paramètre after
     */
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

    /**
     * La méthode appelée au cours du changement d'une entrée texte
     * @param s le paramètre s
     * @param start le paramètre start
     * @param before le paramètre before
     * @param count le paramètre count
     */
    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        mNickname = s.toString();
    }

    /**
     * La méthode appelée après le changement d'une entrée texte
     * @param s le paramètre s
     */
    @Override
    public void afterTextChanged(Editable s) { }
}

package emptyfield.thefearlessglutton.Consumables;

import android.graphics.Bitmap;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Une cerise définie comme étant un consommable
 */
public class Cherry extends Consumable {

    /**
     * Construit une cerise
     * @param location la position de la cerise
     * @param skin l'apparence de la cerise
     */
    public Cherry(GridPoint location, Bitmap skin) {
        super(location, skin, "cherry", 100);
    }
}

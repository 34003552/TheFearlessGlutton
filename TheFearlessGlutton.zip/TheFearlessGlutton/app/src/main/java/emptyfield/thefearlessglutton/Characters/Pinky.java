package emptyfield.thefearlessglutton.Characters;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

import emptyfield.thefearlessglutton.Core.Grid;
import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Le fantôme Pinky
 */
public class Pinky extends Ghost {

    /**
     * Construit Pinky
     * @param location la position initiale du fantôme
     * @param skin l'apparence associée au fantôme
     * @param fearSkin l'apparence associée au fantôme quand il a peur
     */
    public Pinky(GridPoint location, Bitmap skin, Bitmap fearSkin) {
        super(location, skin, fearSkin);
    }

    /**
     * Met à jour le chemin que doit suivre Pinky
     * @param grid la grille dans laquelle se trouvent les personnages
     * @param characters la liste des personnages
     */
    @Override
    public void updatePath(Grid grid, ConcurrentHashMap<String, Character> characters) {
        // un fantôme mort doit impérativement retourner à sa position initiale pour sa resurrection
        if(mDead && mLocation != mInitialLocation) return;

        Player player = (Player) characters.get("player");
        ArrayList<GridPoint> playerPath = player.getPath();
        GridPoint playerPathFirst;
        if (playerPath.size() > 0) {
            playerPathFirst = playerPath.get(playerPath.size()-1);
        } else {
            playerPathFirst = player.getLocation();
        }
        setPath(grid.Dijkstra(mLocation, playerPathFirst));
    }
}

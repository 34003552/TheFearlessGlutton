package emptyfield.thefearlessglutton.Core;

import android.content.SharedPreferences;
import android.os.Bundle;

import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import emptyfield.thefearlessglutton.Activities.GameActivity;
import emptyfield.thefearlessglutton.Characters.Player;
import emptyfield.thefearlessglutton.Consumables.Consumable;
import emptyfield.thefearlessglutton.Consumables.ConsumableFactory;
import emptyfield.thefearlessglutton.Characters.Character;

/**
 * Un contexte de jeu
 */
public class GameContext {
    private int mScore;
    private int mLevel;
    private boolean mFearMode;
    private int mFearDelay;
    private ConcurrentHashMap<String, Character> mCharacters;
    private ConcurrentLinkedQueue<Consumable> mConsumables;
    private GameActivity mGameActivity;
    private String mNickname;
    private SharedPreferences mSettings;

    /**
     * Construit un contexte de jeu
     * @param gameBoardView le plateau de jeu
     * @param characters la liste des personnages
     * @param consumables la liste des consommables
     */
    public GameContext(GameBoardView gameBoardView, ConcurrentHashMap<String, Character> characters, ConcurrentLinkedQueue<Consumable> consumables) {
        mCharacters = characters;
        mConsumables = consumables;
        mGameActivity = (GameActivity)gameBoardView.getContext();

        mScore = 0;
        mLevel = 1;
        mFearMode = false;
        mFearDelay = 0;

        Bundle extras = mGameActivity.getIntent().getExtras();
        mNickname = extras == null ? null : extras.getString("nickname");
        if(mNickname == null) mNickname = "";

        mSettings = mGameActivity.getSharedPreferences("GameContext\n"+mNickname, 0);
        if(extras != null && extras.getBoolean("newGame")) resetPreferences();
    }

    /**
     * Réinitialise les paramètres contextuels
     */
    private void resetPreferences() {
        mSettings.edit().clear().apply();
    }

    /**
     * Charge les paramètres contextuels
     */
    public void loadPreferences(ConsumableFactory consumableFactory) {
        // récupère la position des personnages
        for(Map.Entry<String, Character> e : mCharacters.entrySet()) {
            Character character = e.getValue();
            String characterName = e.getKey();
            GridPoint characterLocation = character.getLocation();
            int characterLocationX = mSettings.getInt(characterName+"X", characterLocation.getX());
            int characterLocationY = mSettings.getInt(characterName+"Y", characterLocation.getY());
            character.setLocation(new GridPoint(characterLocationX, characterLocationY));
        }
        // récupère les consommables
        Set<String> consumables = new HashSet<>();
        consumables = mSettings.getStringSet("consumables", consumables);
        for(String string : consumables) {
            Scanner scanner = new Scanner(string);
            String key = scanner.next();
            int X = scanner.nextInt();
            int Y = scanner.nextInt();
            scanner.close();
            mConsumables.add(consumableFactory.restoreConsumable(new GridPoint(X,Y), key));
        }
        // récupère le score
        mScore = mSettings.getInt("score", mScore);
        // récupère l'indice du niveau
        mLevel = mSettings.getInt("level", mLevel);
        // récupère l'état de peur
        mFearMode = mSettings.getBoolean("fearMode", mFearMode);
        // récupère le delai de peur
        mFearDelay = mSettings.getInt("fearDelay", mFearDelay);
        // récupère le nombre de vies du joueur
        Player player = (Player) mCharacters.get("player");
        player.setLives(mSettings.getInt("lives", player.getLives()));
    }

    /**
     * Sauvegarde les paramètres contextuels
     */
    public void savePreferences() {
        SharedPreferences.Editor editor = mSettings.edit();
        // sauvegarde la position des personnages
        for(Map.Entry<String, Character> e : mCharacters.entrySet()) {
            Character character = e.getValue();
            String characterName = e.getKey();
            GridPoint characterLocation = character.getLocation();
            editor.putInt(characterName+"X", characterLocation.getX());
            editor.putInt(characterName+"Y", characterLocation.getY());
        }
        // sauvegarde les consommables
        Set<String> consumables = new HashSet<>();
        for(Consumable consumable : mConsumables) {
            String category = consumable.getCategory();
            GridPoint consumableLocation = consumable.getLocation();
            if(consumableLocation == null) continue;
            consumables.add(category+" "+consumableLocation.getX()+" "+consumableLocation.getY());
        }
        editor.putStringSet("consumables",consumables);
        // sauvegarde le score
        editor.putInt("score", mScore);
        // sauvegarde l'indice du niveau
        editor.putInt("level", mLevel);
        // sauvegarde l'état de peur
        editor.putBoolean("fearMode", mFearMode);
        // sauvegarde le delai de peur
        editor.putInt("fearDelay", mFearDelay);
        // sauvegare le nombre de vies du joueur
        Player player = (Player) mCharacters.get("player");
        editor.putInt("lives", player.getLives());

        editor.apply();
    }

    /**
     * Récupère le score
     * @return le score
     */
    public int getScore() {
        return mScore;
    }

    /**
     * Définit le score
     * @param score le score
     */
    public void setScore(int score) {
        mScore = score;
    }

    /**
     * Récupère l'indice du niveau
     * @return l'indice du niveau
     */
    public int getLevel() {
        return mLevel;
    }

    /**
     * Définit l'indice du niveau
     * @param level l'indice du niveau
     */
    public void setLevel(int level) {
        mLevel = level;
    }

    /**
     * Récupère le mode de peur
     * @return le mode de peur
     */
    public boolean getFearMode() {
        return mFearMode;
    }

    /**
     * Définit le mode de peur
     * @param fearMode le mode de peur
     */
    public void setFearMode(boolean fearMode) {
        mFearMode = fearMode;
    }

    /**
     * Récupère le delai de peur
     * @return le délai de peur
     */
    public int getFearDelay() {
        return mFearDelay;
    }

    /**
     * Définit le délai de peur
     * @param fearDelay le délai de peur
     */
    public void setFearDelay(int fearDelay) {
        mFearDelay = fearDelay;
    }

    /**
     * Récupère le pseudo
     * @return le pseudo
     */
    public String getNickname() {
        return mNickname;
    }
}

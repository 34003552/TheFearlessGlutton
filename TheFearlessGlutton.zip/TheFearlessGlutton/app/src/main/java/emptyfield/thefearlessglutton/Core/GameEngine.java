package emptyfield.thefearlessglutton.Core;

import android.content.res.Resources;
import android.graphics.Canvas;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import emptyfield.thefearlessglutton.Characters.CharacterFactory;
import emptyfield.thefearlessglutton.Characters.Ghost;
import emptyfield.thefearlessglutton.Characters.Player;
import emptyfield.thefearlessglutton.Characters.Character;
import emptyfield.thefearlessglutton.Configurations.GameConfig;
import emptyfield.thefearlessglutton.Consumables.Consumable;
import emptyfield.thefearlessglutton.Consumables.ConsumableFactory;

/**
 * Un moteur de jeu
 */
public class GameEngine implements Runnable {
    private volatile boolean mRunning;

    private GameContainer mGameContainer;
    private GameConfig mGameConfig;
    private GameContext mGameContext;

    private Grid mGrid;

    private ConsumableFactory mConsumableFactory;
    private ConcurrentLinkedQueue<Consumable> mConsumables;
    private CharacterFactory mCharacterFactory;
    private ConcurrentHashMap<String, Character> mCharacters;

    /**
     * Construit un moteur de jeu
     * @param gameBoardView le plateau de jeu
     * @param gameConfig le paramétrage du jeu
     */
    public GameEngine(GameBoardView gameBoardView, GameConfig gameConfig) {
        mRunning = false;
        mGameConfig = gameConfig;
        mGrid = new Grid(gameConfig);
        mGameContainer = new GameContainer(gameBoardView);

        Resources resources = gameBoardView.getResources();
        mCharacterFactory = new CharacterFactory(resources, gameConfig);
        mConsumableFactory = new ConsumableFactory(resources, gameConfig);

        mCharacters = new ConcurrentHashMap<>();
        mConsumables = new ConcurrentLinkedQueue<>();

        setCharacters();

        mGameContext = new GameContext(gameBoardView, mCharacters, mConsumables);

        Thread thread = new Thread(this);
        thread.setDaemon(true);
        thread.start();
    }

    /**
     * Démarre le moteur de jeu
     */
    public void start() {
        mGameContext.loadPreferences(mConsumableFactory);
        if(mConsumables.isEmpty()) setConsumables();
        mRunning = true;
    }

    /**
     * Interrompt le moteur de jeu
     */
    public void stop() {
        mGameContext.savePreferences();
        mRunning = false;
    }

    /**
     * Le cycle du thread dédié aux mécanismes de jeu
     */
    @Override
    public void run() {
        Player player = (Player) mCharacters.get("player");
        try {
            while(!mRunning);
            mGameContainer.waitInflate();
            mGameContainer.updatePlayerLives(player);
            mGameContainer.updateScore(mGameContext.getScore());
            mGameContainer.updateExtras(mGameContext.getLevel());
            while (mRunning) {
                // Déclenche le début du niveau suivant
                if(mConsumables.isEmpty()) {
                    mGameContext.setLevel(mGameContext.getLevel()+1);
                    mGameContainer.updateExtras(mGameContext.getLevel());
                    resetCharactersLocation();
                    setConsumables();
                }
                // Ajoute un consommable aléatoire
                addRandomConsumable(mGameContext.getLevel());
                // Met à jour l'état de peur
                if (mGameContext.getFearMode()) {
                    if (mGameContext.getFearDelay() != 0) mGameContext.setFearDelay(mGameContext.getFearDelay()-1);
                    else disableFear();
                }
                // Teste la consommation du joueur
                testConsumption();
                // Teste les collisions
                testCollision();
                // Teste la mort du joueur
                if(player.isDead()) {
                    player.rebirth();
                    mGameContainer.updatePlayerLives(player);
                    resetCharactersLocation();
                }
                // Ranime les fantômes
                for (Map.Entry<String, Character> entry : mCharacters.entrySet()) {
                    //if("player".equals(entry.getKey())) continue;
                    Character character = entry.getValue();
                    if(character instanceof Ghost) character.rebirth();
                }
                // Déplace les différents personnages
                for (Map.Entry<String, Character> entry : mCharacters.entrySet()) {
                    Character character = entry.getValue();
                    // Garantit le déplacement permanent des personnages non joueurs
                    if (!(character instanceof Player) && character.getPath().isEmpty()) {
                        character.setPath(mGrid, mGrid.getRandomAccessiblePoint());
                    }
                    character.move();
                }
                mGameContainer.checkGameOver(player);
                // Refraichit l'écran périodiquement
                Thread.sleep(mGameConfig.getSpeed());
                mGameContainer.invalidateGameBoard();
            }
        } catch (InterruptedException e) { }
    }


    /* Les méthodes associées aux consommables */


    /**
     * Ajoute un consommable aléatoire en fonction du niveau
     * @param level l'indice du niveau courant
     */
    private void addRandomConsumable(int level) {
        if (Math.random() > 0.99 && mConsumableFactory.isReady()) {
            Consumable consumable;
            switch(level) {
                case 1:
                    consumable = mConsumableFactory.getCherry();
                    break;
                case 2:
                    consumable = mConsumableFactory.getStrawberry();
                    break;
                case 3:
                case 4:
                    consumable = mConsumableFactory.getOrange();
                    break;
                case 5:
                case 6:
                    consumable = mConsumableFactory.getApple();
                    break;
                case 7:
                case 8:
                    consumable = mConsumableFactory.getMelon();
                    break;
                case 9:
                case 10:
                    consumable = mConsumableFactory.getGalaxian();
                    break;
                case 11:
                case 12:
                    consumable = mConsumableFactory.getBell();
                    break;
                case 13:
                default:
                    consumable = mConsumableFactory.getKey();
                    break;
            }
            mConsumables.add(consumable);
        }
    }

    /**
     * Place les consommables
     */
    private void setConsumables() {
        for (int i = 0; i < mGameConfig.getConsumableBoxes().length; i++) {
            for (int j = 0; j < mGameConfig.getConsumableBoxes()[1].length; j++) {
                GridPoint location = new GridPoint(j, i);
                boolean busy = false;
                // Empêche le placement de consommables sur un personnage
                for(Map.Entry entry : mCharacters.entrySet()) {
                    Character character = (Character)entry.getValue();
                    if (character.getLocation().equals(location)) {
                        busy = true;
                    }
                }
                if (busy) continue;
                // Place les super pac-gommes
                for (int k = 0; k < mGameConfig.getLocationBigGums().length; k++) {
                    if (mGameConfig.getLocationBigGums()[k].equals(location)) {
                        mConsumables.add(mConsumableFactory.getBigGum(location));
                        busy = true;
                    }
                }
                if (busy) continue;
                // Place les pac-gommes
                if (mGameConfig.getConsumableBoxes()[i][j]) {
                    mConsumables.add(mConsumableFactory.getGum(location));
                }
            }
        }
    }

    /**
     * Teste la consommation du joueur
     */
    private void testConsumption() {
        Player player = (Player) mCharacters.get("player");
        for (Consumable consumable : mConsumables) {
            if (!player.eat(consumable)) continue;
            switch (consumable.getCategory()) {
                case "bigGum":
                    unableFear(20);
                    break;
                default:
                    break;
            }
            mGameContext.setScore(mGameContext.getScore()+consumable.getValue());
            mGameContainer.updateScore(mGameContext.getScore());
            mConsumables.remove(consumable);
            mConsumableFactory.freeLocation(consumable.getLocation());
        }
    }


    /* Les méthodes associées à la peur */


    /**
     * Active la peur
     * @param delay le délai durant lequel elle fera effet
     */
    private void unableFear(int delay) {
        mGameContext.setFearMode(true);
        mGameContext.setFearDelay(delay);
        for (Map.Entry<String, Character> entry : mCharacters.entrySet()) {
            Character character = entry.getValue();
            if(character instanceof Ghost) {
                ((Ghost)character).setFearMode(true);
                character.setPath(mGrid, mGrid.getRandomAccessiblePoint());
            }
        }
    }

    /**
     * Désactive la peur
     */
    private void disableFear() {
        mGameContext.setFearMode(false);
        for (Map.Entry<String, Character> entry : mCharacters.entrySet()) {
            Character character = entry.getValue();
            if(character instanceof Ghost) {
                ((Ghost)character).setFearMode(false);
            }
        }
        updateGhostsPaths();
    }


    /* Les méthodes associées aux personnages */


    /**
     * Place les personnages
     */
    private void setCharacters() {
        mCharacters.put("player", mCharacterFactory.getPlayer());
        mCharacters.put("blinky", mCharacterFactory.getBlinky());
        mCharacters.put("pinky", mCharacterFactory.getPinky());
        mCharacters.put("inky", mCharacterFactory.getInky());
        mCharacters.put("clyde", mCharacterFactory.getClyde());
    }

    /**
     * Définit le chemin que doit suivre le joueur
     * @param posx la position que doit atteidre le joueur sur l'axe x
     * @param posy la position que doit atteidre le joueur sur l'axe y
     */
    public void setPlayerPath(float posx, float posy) {
        Player player = (Player) mCharacters.get("player");
        player.setPath(mGrid, mGrid.toGridPoint(posx, posy));
        updateGhostsPaths();
    }

    /**
     * Met à jour le chemin des fantômes
     */
    private void updateGhostsPaths() {
        for(Map.Entry<String, Character> entry : mCharacters.entrySet()) {
            Character character = entry.getValue();
            if(character instanceof Ghost) {
                ((Ghost)character).updatePath(mGrid, mCharacters);
            }
        }
    }

    /**
     * Teste les collisions
     */
    private void testCollision() {
        Player player = (Player) mCharacters.get("player");
        for (Map.Entry<String, Character> entry : mCharacters.entrySet()) {
            Character character = entry.getValue();
            if (entry.getKey().equals("player") || character.isDead()) continue;
            if (player.collidesWith(character)) {
                if (mGameContext.getFearMode()) {
                    character.setPath(mGrid);
                    character.die();
                } else {
                    player.die();
                }
            }
        }
    }

    /**
     * Réinitialise la position des personnages
     */
    private void resetCharactersLocation() {
        for (Map.Entry<String, Character> entry : mCharacters.entrySet()) {
            Character character = entry.getValue();
            character.resetLocation();
        }
    }

    /**
     * Dessine le plateau de jeu
     * @param canvas le paramètre canvas
     * @param x la position centrale de la zone de dessin sur l'axe horizontal
     * @param y la position centrale de la zone de dessin sur l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    public void draw(Canvas canvas, int x, int y, int width, int height) {
        // Dessine la grille
        mGrid.draw(canvas, x, y, width, height);
        // Récupère les dimensions des cases de la grille
        int boxWidth = (int) mGrid.getBoxWidth();
        int boxHeight = (int) mGrid.getBoxHeight();
        // Dessine les personnages
        for (Map.Entry<String, Character> entry : mCharacters.entrySet()) {
            Character character = entry.getValue();
            GridPoint characterLocation = character.getLocation();
            character.draw(canvas, (int) mGrid.getOnScreenX(characterLocation), (int) mGrid.getOnScreenY(characterLocation), boxWidth, boxHeight);
        }
        // Dessine les consommables
        for (Consumable consumable : mConsumables) {
            GridPoint consumableLocation = consumable.getLocation();
            if(consumableLocation == null) continue;
            consumable.draw(canvas, (int) mGrid.getOnScreenX(consumableLocation), (int) mGrid.getOnScreenY(consumableLocation), boxWidth, boxHeight);
        }
    }
}

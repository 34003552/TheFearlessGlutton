package emptyfield.thefearlessglutton.Consumables;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Un consommable modèle
 */
public abstract class Consumable {
    private GridPoint mLocation;
    private Bitmap mSkin;
    private String mCategory;
    private int mValue;

    /**
     * Construit un consommable
     * @param location la position du consommable
     * @param skin l'apparence du consommable
     * @param category la catégorie du consommable
     * @param value la valeur du consommable
     */
    public Consumable(GridPoint location, Bitmap skin, String category, int value) {
        mLocation = location;
        mSkin = skin;
        mCategory = category;
        mValue = value;
    }

    /**
     * Récupère la position du consommable
     * @return la position du consommable
     */
    public GridPoint getLocation() {
        return mLocation;
    }

    /**
     * Récupère la catégorie du consommable
     * @return la catégorie du consommable
     */
    public String getCategory() {
        return mCategory;
    }

    /**
     * Récupère la valeur du consommable
     * @return la valeur du consommable
     */
    public int getValue() {
        return mValue;
    }

    /**
     * Dessine le consommable
     * @param canvas le paramètre canvas
     * @param x la position centrale horizontale de la zone de dessin
     * @param y la position centrale verticale de la zone de dessin
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    public void draw(Canvas canvas, int x, int y, int width, int height) {
        Paint p = new Paint();
        canvas.drawBitmap(mSkin, null, new RectF(x - width / 2, y - height / 2, x + width / 2, y + height / 2), p);
    }
}

package emptyfield.thefearlessglutton.Characters;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

import emptyfield.thefearlessglutton.Core.Grid;
import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Un fantôme de type Inky
 */
public class Inky extends Ghost {

    /**
     * Construit Inky
     * @param location la position initiale du fantôme
     * @param skin l'apparence associée au fantôme
     * @param fearSkin l'apparence associée au fantôme quand il a peur
     */
    public Inky(GridPoint location, Bitmap skin, Bitmap fearSkin) {
        super(location, skin, fearSkin);
    }

    /**
     * Met à jour le chemin du fantôme Inky
     * @param grid la grille dans laquelle se trouvent les personnages
     * @param characters la liste des personnages
     */
    @Override
    public void updatePath(Grid grid, ConcurrentHashMap<String, Character> characters) {
        // un fantôme mort doit impérativement retourner à sa position initiale pour sa resurrection
        if(mDead && mLocation != mInitialLocation) return;

        Player player = (Player) characters.get("player");
        Blinky blinky = (Blinky) characters.get("blinky");
        ArrayList<GridPoint> blinkyPath = blinky.getPath();
        GridPoint inkyDestination = player.getLocation();
        for (int i = 0; i < blinkyPath.size() + 4; i++) {
            ArrayList<GridPoint> neighborhood = grid.getPointNeighborhood(inkyDestination);
            int index = (int) (Math.random() * neighborhood.size());
            GridPoint neighbor = neighborhood.get(index);
            if(blinkyPath.contains(neighbor)) {
                neighbor = neighborhood.get((index+1)%neighborhood.size());
            }
            inkyDestination = neighbor;
        }
        setPath(grid.Dijkstra(mLocation, inkyDestination));
    }
}

package emptyfield.thefearlessglutton.Core;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import emptyfield.thefearlessglutton.Activities.R;
import emptyfield.thefearlessglutton.Configurations.GameConfig;
import emptyfield.thefearlessglutton.Configurations.GameConfigClassic;

/**
 * La vue hébergeant le plateau de jeu
 */
public class GameBoardView extends View implements View.OnTouchListener {
    private GameEngine gameEngine;

    /**
     * Construit la vue du plateau de jeu
     * @param context le paramètre context
     */
    public GameBoardView(Context context) {
        super(context);
        init(null, 0);
    }

    /**
     * Construit la vue du plateau de jeu
     * @param context le paramètre context
     * @param attrs le paramètre attrs
     */
    public GameBoardView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs, 0);
    }

    /**
     * Construit la vue du plateau de jeu
     * @param context le paramètre context
     * @param attrs le paramètre attrs
     * @param defStyle le paramètre defStyle
     */
    public GameBoardView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(attrs, defStyle);
    }

    /**
     * Initialise la vue
     * @param attrs le paramètre attrs
     * @param defStyle le paramètre defStyle
     */
    private void init(AttributeSet attrs, int defStyle) {
        // Load attributes
        final TypedArray a = getContext().obtainStyledAttributes(attrs, R.styleable.GameBoardView, defStyle, 0);

        String gameConfigString = a.getString(R.styleable.GameBoardView_game_config);
        if (gameConfigString == null) gameConfigString = "";

        a.recycle();

        GameConfig gameConfig;
        switch (gameConfigString) {
            case "classic":
            default:
                gameConfig = new GameConfigClassic();
                break;
        }

        gameEngine = new GameEngine(this, gameConfig);
        this.setOnTouchListener(this);
    }

    /**
     * La méthode appelée pour le dessin
     * @param canvas le paramètre canvas
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int width = getWidth();
        int height = getHeight();

        int contentWidth = width - paddingLeft - paddingRight;
        int contentHeight = height - paddingTop - paddingBottom;

        gameEngine.draw(canvas, width / 2, height / 2, contentWidth, contentHeight);
    }

    /**
     * La méthode appelée lors de la détection d'un évènement tactile
     * @param view le paramètre view
     * @param event le paramètre event
     * @return un booléen
     */
    @Override
    public boolean onTouch(View view, MotionEvent event) {
        switch (view.getId()) {
            case R.id.gameBoard:
                gameEngine.setPlayerPath(event.getX(), event.getY());
                break;
        }
        return false;
    }

    /**
     * La méthode appelée lors de la détection d'un clic
     * @return un booléen
     */
    @Override
    public boolean performClick() {
        return super.performClick();
    }

    /**
     * Démarre le moteur de jeu
     */
    public void startEngine() {
        gameEngine.start();
    }

    /**
     * Interrompt le moteur de jeu
     */
    public void stopEngine() {
        gameEngine.stop();
    }
}

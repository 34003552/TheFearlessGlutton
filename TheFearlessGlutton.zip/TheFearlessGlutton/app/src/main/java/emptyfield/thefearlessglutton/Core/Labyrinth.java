package emptyfield.thefearlessglutton.Core;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import emptyfield.thefearlessglutton.Configurations.GameConfig;

/**
 * Un labyrinthe pour une grille
 */
public class Labyrinth {
    private int mWidth;
    private int mHeight;
    private boolean mHWalls[][];
    private boolean mVWalls[][];
    private Bitmap mBitmap;
    private float mHWallLength;
    private float mVWallLength;

    /**
     * Construit un labyrinthe
     * @param gameConfig la configuration de jeu
     */
    public Labyrinth(GameConfig gameConfig) {
        mWidth = gameConfig.getGridWidth();
        mHeight = gameConfig.getGridHeight();
        mHWalls = gameConfig.getHWalls();
        mVWalls = gameConfig.getVWalls();
    }

    /**
     * Vérifie la présence d'un mur horizontal à un emplacement spécifique
     * @param x la position horizontale dans l'espace des murs horizontaux
     * @param y la position verticale dans l'espace des murs horizontaux
     * @return vrai si un mur existe, faux sinon
     */
    public boolean hasHorizontalWallAt(int x, int y) {
        return mHWalls[y][x];
    }

    /**
     * Vérifie la présence d'un mur vertical à un emplacement spécifique
     * @param x la position horizontale dans l'espace des murs verticaux
     * @param y la position verticale dans l'espace des murs verticaux
     * @return vrai si un mur existe, faux sinon
     */
    public boolean hasVerticalWallAt(int x, int y) {
        return mVWalls[y][x];
    }

    /**
     * Dessine les murs horizontaux
     * @param canvas le paramètre canvas
     * @param x la position centrale de la zone de dessin sur l'axe horizontal
     * @param y la position centrale de la zone de dessin sur l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     * @param paint le paramètre paint
     */
    private void drawHorizontalWalls(Canvas canvas, int x, int y, int width, int height, Paint paint) {
        for (int i = 0; i <= mHeight; i++) {
            long startY = Math.round(y - height / 2 + i * mVWallLength);
            long stopY = startY;
            for (int j = 0; j < mWidth; j++) {
                long startX = Math.round(x - width / 2 + j * mHWallLength);
                long stopX = Math.round(x - width / 2 + (j + 1) * mHWallLength);
                if (mHWalls[i][j]) {
                    canvas.drawLine(startX, startY, stopX, stopY, paint);
                }
            }
        }
    }

    /**
     * Dessine les murs verticaux
     * @param canvas le paramètre canvas
     * @param x la position centrale de la zone de dessin sur l'axe horizontal
     * @param y la position centrale de la zone de dessin sur l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     * @param paint le paramètre paint
     */
    private void drawVerticalWalls(Canvas canvas, int x, int y, int width, int height, Paint paint) {
        for (int i = 0; i < mHeight; i++) {
            long startY = Math.round(y - height / 2 + i * mVWallLength);
            long stopY = Math.round(y - height / 2 + (i + 1) * mVWallLength);
            for (int j = 0; j <= mWidth; j++) {
                long startX = Math.round(x - width / 2 + j * mHWallLength);
                long stopX = startX;
                if (mVWalls[i][j]) {
                    canvas.drawLine(startX, startY, stopX, stopY, paint);
                }
            }
        }
    }

    /**
     * Dessine le labyrinthe
     * @param canvas le paramètre canves
     * @param x la position centrale de la zone de dessin sur l'axe horizontal
     * @param y la position centrale de la zone de dessin sur l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    public void draw(Canvas canvas, int x, int y, int width, int height) {
        mHWallLength = width / mWidth;
        mVWallLength = height / mHeight;
        Paint paint = new Paint();
        paint.setColor(Color.BLUE);
        if (mBitmap != null) {
            canvas.drawBitmap(mBitmap, 0, 0, paint);
        } else {
            mBitmap = Bitmap.createBitmap((int) (width + mHWallLength), (int) (height + mVWallLength), Bitmap.Config.RGB_565);
            Canvas nCanvas = new Canvas(mBitmap);
            drawHorizontalWalls(nCanvas, x, y, width, height, paint);
            drawVerticalWalls(nCanvas, x, y, width, height, paint);
        }
    }
}

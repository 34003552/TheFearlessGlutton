package emptyfield.thefearlessglutton.Configurations;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Un paramétrage de jeu
 */
public abstract class GameConfig {
    protected boolean[][] mHWalls;
    protected boolean[][] mVWalls;
    protected boolean[][] mConsumableBoxes;
    protected GridPoint mLocationPlayer;
    protected GridPoint mLocationBlinky;
    protected GridPoint mLocationPinky;
    protected GridPoint mLocationInky;
    protected GridPoint mLocationClyde;
    protected GridPoint[] mLocationBigGums;
    protected GridPoint[] mLocationExtras;
    private int mSpeed;
    private int mGridWidth;
    private int mGridHeight;

    /**
     * Définit un paramétrage de jeu
     * @param speed la vitesse de déplacement des personnages en millisecondes
     * @param gridWidth la largeur de la grille de jeu
     * @param gridHeight la hauteur de la grille de jeu
     */
    public GameConfig(int speed, int gridWidth, int gridHeight) {
        mSpeed = speed;
        mGridHeight = gridHeight;
        mGridWidth = gridWidth;
    }

    /**
     * Récupère la vitesse de déplacement des personnages
     * @return la vitesse de déplacement des personnages (en millisecondes)
     */
    public int getSpeed() {
        return mSpeed;
    }

    /**
     * Récupère la largeur de la grille de jeu
     * @return la largeur de la grille de jeu
     */
    public int getGridWidth() {
        return mGridWidth;
    }

    /**
     * Récupère la hauteur de la grille de jeu
     * @return la hauteur de la grille de jeu
     */
    public int getGridHeight() {
        return mGridHeight;
    }

    /**
     * Récupère la matrice des murs horizontaux
     * @return la matrice des murs horizontaux
     */
    public boolean[][] getHWalls() {
        return mHWalls;
    }

    /**
     * Récupère la matrice des murs verticaux
     * @return la matrice des murs verticaux
     */
    public boolean[][] getVWalls() {
        return mVWalls;
    }

    /**
     * Récupère la matrice des cases où peuvent se trouver des consommables
     * @return la matrice des cases où peuvent se trouver des consommables
     */
    public boolean[][] getConsumableBoxes() {
        return mConsumableBoxes;
    }

    /**
     * Récupère la position initiale du joueur
     * @return la position initiale du joueur
     */
    public GridPoint getLocationPlayer() {
        return mLocationPlayer;
    }

    /**
     * Récupère la position initiale du fantôme Blinky
     * @return la position initiale du fantôme Blinky
     */
    public GridPoint getLocationBlinky() {
        return mLocationBlinky;
    }

    /**
     * Récupère la position initiale du fantôme Pinky
     * @return la position initiale du fantôme Pinky
     */
    public GridPoint getLocationPinky() {
        return mLocationPinky;
    }

    /**
     * Récupère la position initiale du fantôme Inky
     * @return la position initiale du fantôme Inky
     */
    public GridPoint getLocationInky() {
        return mLocationInky;
    }

    /**
     * Récupère la position initiale du fantôme Clyde
     * @return la position initiale du fantôme Clyde
     */
    public GridPoint getLocationClyde() {
        return mLocationClyde;
    }

    /**
     * Récupère la position des super pac-gommes
     * @return la position des super pac-gommes
     */
    public GridPoint[] getLocationBigGums() {
        return mLocationBigGums;
    }

    /**
     * Récupère les positions où peuvent se trouver les bonus
     * @return les positions où peuvent se trouver les bonus
     */
    public GridPoint[] getLocationExtras() {
        return mLocationExtras;
    }
}

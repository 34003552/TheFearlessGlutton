package emptyfield.thefearlessglutton.Characters;

import android.graphics.Bitmap;

import emptyfield.thefearlessglutton.Consumables.Consumable;
import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Un personnage joueur
 */
public class Player extends Character {
    private int mLives;

    /**
     * Construit un personnage joueur
     * @param location la position initiale du joueur
     * @param skin l'apparence associée au joueur
     */
    public Player(GridPoint location, Bitmap skin) {
        super(location, skin);
        mLives = 3;
    }

    /**
     * Vérifie l'assimilation d'un consommable
     * @param consumable un consommable
     * @return true si le personnage mange le consommable, false sinon
     */
    public boolean eat(Consumable consumable) {
        return mLocation.equals(consumable.getLocation());
    }

    /**
     * Récupère le nombre de vies restantes du joueur
     * @return le nombre de vies restantes du joueur
     */
    public int getLives() {
        return mLives;
    }

    /**
     * Incrémente le nombre de vies du joueur
     */
    public void addLive() {
        mLives++;
    }

    /**
     * Définit le nombre de vies du joueur
     * @param lives le nombre de vies
     */
    public void setLives(int lives) {
        mLives = lives;
    }

    /**
     * Tue le personnage joueur
     */
    @Override
    public void die() {
        super.die();
        mLives--;
    }
}

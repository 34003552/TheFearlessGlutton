package emptyfield.thefearlessglutton.Consumables;

import android.graphics.Bitmap;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Une orange définie comme étant un consommable
 */
public class Orange extends Consumable {

    /**
     * Construit une orange
     * @param location la position de l'orange
     * @param skin l'apparence de l'orange
     */
    public Orange(GridPoint location, Bitmap skin) {
        super(location, skin, "orange", 500);
    }
}

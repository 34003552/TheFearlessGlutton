package emptyfield.thefearlessglutton.Consumables;

import android.graphics.Bitmap;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Une fraise définie comme étant un consommable
 */
public class Strawberry extends Consumable {

    /**
     * Construit une fraise
     * @param location la position de la fraise
     * @param skin l'apparence de la fraise
     */
    public Strawberry(GridPoint location, Bitmap skin) {
        super(location, skin, "strawberry", 300);
    }
}

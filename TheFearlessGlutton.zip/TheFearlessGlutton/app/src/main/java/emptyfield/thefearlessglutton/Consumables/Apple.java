package emptyfield.thefearlessglutton.Consumables;

import android.graphics.Bitmap;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Une pomme définie comme étant un consommable
 */
public class Apple extends Consumable {

    /**
     * Construit une pomme
     * @param location la position de la pomme
     * @param skin l'apparence de la pomme
     */
    public Apple(GridPoint location, Bitmap skin) {
        super(location, skin, "apple", 700);
    }
}

package emptyfield.thefearlessglutton.Consumables;

import android.graphics.Bitmap;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Un galaxian défini comme étant un consommable
 */
public class Galaxian extends Consumable {

    /**
     * Construit un galaxian
     * @param location la position du galaxian
     * @param skin l'apparence du galaxian
     */
    public Galaxian(GridPoint location, Bitmap skin) {
        super(location, skin, "galaxian", 2000);
    }
}

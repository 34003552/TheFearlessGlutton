package emptyfield.thefearlessglutton.Consumables;

import android.graphics.Bitmap;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Une clé définie comme étant un consommable
 */
public class Key extends Consumable {

    /**
     * Construit une clé
     * @param location la position de la clé
     * @param skin l'apparence de la clé
     */
    public Key(GridPoint location, Bitmap skin) {
        super(location, skin, "key", 5000);
    }
}

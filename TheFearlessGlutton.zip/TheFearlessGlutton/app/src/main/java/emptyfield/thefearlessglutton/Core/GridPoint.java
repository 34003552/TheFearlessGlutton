package emptyfield.thefearlessglutton.Core;

/**
 * La classe définissant un point de grille
 */
public class GridPoint {
    private int mX;
    private int mY;

    /**
     * Construit un point de grille
     * @param x la position horizontale dans une grille
     * @param y la position verticale dans une grille
     */
    public GridPoint(int x, int y) {
        mX = x;
        mY = y;
    }

    /**
     * Récupère la position horizontale
     * @return la position horizontale
     */
    public int getX() {
        return mX;
    }

    /**
     * Récupère la position verticale
     * @return la position verticale
     */
    public int getY() {
        return mY;
    }

    /**
     * Génère une valeur de hachage pour les collections
     * @return une valeur de hachage
     */
    @Override
    public int hashCode() {
        return 31*mX + mY;
    }

    /**
     * Définit l'égalité des points d'une grille pour les collections
     * @param object un point d'une grille
     * @return true si les points sont égaux et false sinon
     */
    @Override
    public boolean equals(Object object) {
        if(object == null || !(object instanceof GridPoint)) return false;
        GridPoint gridPoint = (GridPoint) object;
        return (mX == gridPoint.mX && mY == gridPoint.mY);
    }
}

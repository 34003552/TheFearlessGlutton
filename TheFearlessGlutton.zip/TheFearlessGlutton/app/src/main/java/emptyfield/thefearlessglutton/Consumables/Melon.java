package emptyfield.thefearlessglutton.Consumables;

import android.graphics.Bitmap;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Un melon définit comme étant un consommable
 */
public class Melon extends Consumable {

    /**
     * Construit un melon
     * @param location la position du melon
     * @param skin l'apparence du melon
     */
    public Melon(GridPoint location, Bitmap skin) {
        super(location, skin, "melon", 1000);
    }
}

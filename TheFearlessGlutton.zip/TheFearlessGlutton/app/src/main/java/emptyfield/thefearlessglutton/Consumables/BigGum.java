package emptyfield.thefearlessglutton.Consumables;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Une super pac-gomme définie comme étant un consommable
 */
public class BigGum extends Consumable {

    /**
     * Construit une super pac-gomme
     * @param location la position de la super pac-gomme
     */
    public BigGum(GridPoint location) {
        super(location, null, "bigGum", 50);
    }

    /**
     * Dessine la super pac-gomme
     * @param canvas le paramètre canvas
     * @param x la position centrale horizontale de la zone de dessin
     * @param y la position centrale verticale de la zone de dessin
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    @Override
    public void draw(Canvas canvas, int x, int y, int width, int height) {
        Paint p = new Paint();
        p.setColor(Color.GREEN);
        canvas.drawOval(new RectF(x - width / 4, y - height / 4, x + width / 4, y + height / 4), p);
    }
}

package emptyfield.thefearlessglutton.Characters;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;

import emptyfield.thefearlessglutton.Consumables.Consumable;
import emptyfield.thefearlessglutton.Core.Grid;
import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Un personnage modèle
 */
public abstract class Character {
    protected boolean mDead;
    protected Bitmap mSkin;
    protected GridPoint mInitialLocation;
    protected GridPoint mLocation;
    protected ConcurrentLinkedQueue<GridPoint> mPath;

    /**
     * Construit un personnage
     * @param location la position initiale du personnage
     * @param skin l'apparence du personnage
     */
    public Character(GridPoint location, Bitmap skin) {
        mLocation = location;
        mInitialLocation = location;
        mPath = new ConcurrentLinkedQueue<>();
        mDead = false;
        mSkin = skin;
    }

    /**
     * Récupère le chemin que suit actuellement le personnage
     * @return le chemin associé au personnage
     */
    public ArrayList<GridPoint> getPath() {
        return new ArrayList<>(mPath);
    }

    /**
     * Définit le chemin que doit suivre le personnage
     * @param grid la grille dans laquelle se trouve le personnage
     * @param gridPoint la position que doit atteindre le personnage
     */
    public void setPath(Grid grid, GridPoint gridPoint) {
        setPath(grid.Dijkstra(mLocation, gridPoint));
    }

    /**
     * Définit le chemin que doit suivre le personnage jusqu'à sa position initiale
     * @param grid la grille dans laquelle se trouve le personnage
     */
    public void setPath(Grid grid) {
        setPath(grid, mInitialLocation);
    }

    /**
     * Définit le chemin que doit suivre le personnage à partir d'une liste de points
     * @param path le chemin que doit suivre le personnage
     */
    public void setPath(ArrayList<GridPoint> path) {
        mPath.clear();
        mPath.addAll(path);
    }

    /**
     * Récupère la position courante du personnage
     * @return la position courante du personnage
     */
    public GridPoint getLocation() {
        return mLocation;
    }

    /**
     * Définit la position du personnage
     * @param location la nouvelle position du personnage
     */
    public void setLocation(GridPoint location) {
        mLocation = location;
    }

    /**
     * Repositionne le personnage à sa position initiale
     */
    public void resetLocation() {
        mPath.clear();
        mLocation = mInitialLocation;
    }

    /**
     * Déplace le personnage le long du chemin qu'il suit actuellement
     */
    public void move() {
        GridPoint location = mPath.poll();
        if (location == null) return;
        mLocation = location;
    }

    /**
     * Vérifie qu'un personnage est mort
     * @return l'état de mort du personnage
     */
    public boolean isDead() {
        return mDead;
    }

    /**
     * Tue le personnage
     */
    public void die() {
        mDead = true;
    }

    /**
     * Ressuscite le personnage
     */
    public void rebirth() {
        mDead = false;
    }

    /**
     * Vérifie une collision entre deux personnages
     * @param character un personnage
     * @return true si les personnages entrent en collision, false sinon
     */
    public boolean collidesWith(Character character) {
        return character.getLocation().equals(mLocation) || character.getLocation().equals(mPath.peek());
    }

    /**
     * Dessine le personnage
     * @param canvas le paramètre canvas
     * @param x la coordonnée centrale de la zone de dessin suivant l'axe horizontal
     * @param y la coordonnée centrale de la zone de dessin suivant l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    public void draw(Canvas canvas, int x, int y, int width, int height) {
        Paint p = new Paint();
        canvas.drawBitmap(mSkin, null, new RectF(x - width / 2, y - height / 2, x + width / 2, y + height / 2), p);
    }
}

package emptyfield.thefearlessglutton.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * L'activité hébergeant le menu principal
 */
public class MainMenuActivity extends AppCompatActivity implements View.OnClickListener {
    private Button buttonNewGame, buttonLoadGame, buttonShowScores, buttonQuit;

    /**
     * La méthode appelée lors de la création de l'activité
     * @param savedInstanceState le paramètre savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        buttonNewGame = findViewById(R.id.buttonNewGame);
        buttonLoadGame = findViewById(R.id.buttonLoadGame);
        buttonShowScores = findViewById(R.id.buttonShowScores);
        buttonQuit = findViewById(R.id.buttonQuit);

        buttonNewGame.setOnClickListener(this);
        buttonLoadGame.setOnClickListener(this);
        buttonShowScores.setOnClickListener(this);
        buttonQuit.setOnClickListener(this);
    }

    /**
     * La méthode appelée lors d'un clic sur un bouton
     * @param view le paramètre view
     */
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.buttonNewGame:
                Intent intent1 = new Intent(MainMenuActivity.this, GameActivity.class);
                // Démarre l'activité GameActivity avec le paramètre newGame
                intent1.putExtra("newGame", true);
                startActivity(intent1);
                break;
            case R.id.buttonLoadGame:
                Intent intent2 = new Intent(MainMenuActivity.this, LoadSaveActivity.class);
                // Démarre l'activité LoadSaveActivity
                startActivity(intent2);
                break;
            case R.id.buttonShowScores:
                Intent intent3 = new Intent(MainMenuActivity.this, ShowScoresActivity.class);
                // Démarre l'activité ShowScoresActivity
                startActivity(intent3);
                break;
            case R.id.buttonQuit:
                // Termine l'application
                finish();
                System.exit(0);
                break;
        }
    }
}

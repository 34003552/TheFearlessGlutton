package emptyfield.thefearlessglutton.Consumables;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.ArrayList;

import emptyfield.thefearlessglutton.Activities.R;
import emptyfield.thefearlessglutton.Configurations.GameConfig;
import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Une fabrique pour les consommables
 */
public class ConsumableFactory {
    private GameConfig mGameConfig;
    private ArrayList<GridPoint> mUsedLocations;
    private Bitmap mCherrySkin, mStrawberrySkin, mOrangeSkin, mAppleSkin, mMelonSkin, mGalaxianSkin, mBellSkin, mKeySkin;

    /**
     * Construit une fabrique de consommables
     * @param resources le paramètre resources
     * @param gameConfig les paramètres de jeu
     */
    public ConsumableFactory(Resources resources, GameConfig gameConfig) {
        mGameConfig = gameConfig;
        mUsedLocations = new ArrayList<>();
        mCherrySkin = BitmapFactory.decodeResource(resources, R.drawable.cherry);
        mStrawberrySkin = BitmapFactory.decodeResource(resources, R.drawable.strawberry);
        mOrangeSkin = BitmapFactory.decodeResource(resources, R.drawable.orange);
        mAppleSkin = BitmapFactory.decodeResource(resources, R.drawable.apple);
        mMelonSkin = BitmapFactory.decodeResource(resources, R.drawable.melon);
        mGalaxianSkin = BitmapFactory.decodeResource(resources, R.drawable.galaxian);
        mBellSkin = BitmapFactory.decodeResource(resources, R.drawable.bell);
        mKeySkin = BitmapFactory.decodeResource(resources, R.drawable.key);
    }

    /**
     * Construit une pac-gomme
     * @param location la position de la pac-gomme
     * @return une pac-gomme
     */
    public Gum getGum(GridPoint location) {
        return new Gum(location);
    }

    /**
     * Construit une super pac-gomme
     * @param location la position de la pac-gomme
     * @return une super pac-gomme
     */
    public BigGum getBigGum(GridPoint location) {
        return new BigGum(location);
    }

    /**
     * Renvoie une position valide pour un bonus
     * @return une position valide pour un bonus ou null s'il n'en existe pas
     */
    private GridPoint newLocation() {
        GridPoint location = null;
        for(int i = 0; i < mGameConfig.getLocationExtras().length; i++) {
            GridPoint tempLoc = mGameConfig.getLocationExtras()[i];
            if(!mUsedLocations.contains(tempLoc)) {
                location = tempLoc;
                mUsedLocations.add(tempLoc);
            }
        }
        return location;
    }

    /**
     * Vérifie si la fabrique est prête à construire un bonus
     * @return true si la fabrique est prête, false sinon
     */
    public boolean isReady() {
        return (mUsedLocations.size() != mGameConfig.getLocationExtras().length);
    }

    /**
     * Libère une position pour un bonus
     * @param gridPoint la position à libérer
     */
    public void freeLocation(GridPoint gridPoint) {
        mUsedLocations.remove(gridPoint);
    }

    /**
     * Construit une cerise sur un emplacement réservé aux bonus
     * @return une cerise
     */
    public Cherry getCherry() {
        return new Cherry(newLocation(), mCherrySkin);
    }

    /**
     * Construit une fraise sur un emplacement réservé aux bonus
     * @return une fraise
     */
    public Strawberry getStrawberry() {
        return new Strawberry(newLocation(), mStrawberrySkin);
    }

    /**
     * Construit une orange sur un emplacement réservé aux bonus
     * @return une orange
     */
    public Orange getOrange() {
        return new Orange(newLocation(), mOrangeSkin);
    }

    /**
     * Construit une pomme sur un emplacement réservé aux bonus
     * @return une pomme
     */
    public Apple getApple() {
        return new Apple(newLocation(), mAppleSkin);
    }

    /**
     * Construit un melon sur un emplacement réservé aux bonus
     * @return un melon
     */
    public Melon getMelon() {
        return new Melon(newLocation(), mMelonSkin);
    }

    /**
     * Construit un galaxian sur un emplacement réservé aux bonus
     * @return un galaxian
     */
    public Galaxian getGalaxian() {
        return new Galaxian(newLocation(), mGalaxianSkin);
    }

    /**
     * Construit une cloche sur un emplacement réservé aux bonus
     * @return une cloche
     */
    public Bell getBell() {
        return new Bell(newLocation(), mBellSkin);
    }

    /**
     * Construit une clé sur un emplacement réservé aux bonus
     * @return une clé
     */
    public Key getKey() {
        return new Key(newLocation(), mKeySkin);
    }

    /**
     * Reconstruit un consommable à une position spécifique à partir de sa catégorie
     * @param location la position du consommable
     * @param category la catégorie du consommable
     * @return un comsommable
     */
    public Consumable restoreConsumable(GridPoint location, String category) {
        mUsedLocations.add(location);
        switch(category) {
            case "gum":
                return new Gum(location);
            case "bigGum":
                return new BigGum(location);
            case "cherry":
                return new Cherry(location, mCherrySkin);
            case "strawberry":
                return new Strawberry(location, mStrawberrySkin);
            case "orange":
                return new Orange(location, mOrangeSkin);
            case "apple":
                return new Apple(location, mAppleSkin);
            case "melon":
                return new Melon(location, mMelonSkin);
            case "galaxian":
                return new Galaxian(location, mGalaxianSkin);
            case "bell":
                return new Bell(location, mBellSkin);
            case "key":
                return new Key(location, mKeySkin);
            default:
                return null;
        }
    }
}

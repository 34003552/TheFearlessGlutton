package emptyfield.thefearlessglutton.Core;

import android.content.Intent;
import android.support.v4.view.ViewCompat;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import emptyfield.thefearlessglutton.Activities.GameActivity;
import emptyfield.thefearlessglutton.Activities.GameOverActivity;
import emptyfield.thefearlessglutton.Activities.R;
import emptyfield.thefearlessglutton.Characters.Player;

import static android.view.View.INVISIBLE;
import static android.view.View.VISIBLE;

/**
 * Un conteneur de jeu permettant la communication avec l'activité de jeu depuis le plateau de jeu
 */
public class GameContainer {
    private GameBoardView mGameBoardView;
    private GameActivity mGameActivity;
    private LinearLayout mBottomLayoutExtras;
    private RelativeLayout mTopLayout;
    private LinearLayout mBottomLayoutLives;
    private boolean mGameEnded;
    private int mLifeScore;

    /**
     * Construit un conteneur de jeu
     * @param gameBoardView la vue du plateau de jeu
     */
    public GameContainer(GameBoardView gameBoardView) {
        mGameBoardView = gameBoardView;
        mGameActivity = (GameActivity)gameBoardView.getContext();
        mGameEnded = false;
        mLifeScore = 0;
    }

    /**
     * Attend le dessin de l'activité puis récupère les références des vues
     */
    public void waitInflate() {
        View rootView = mGameActivity.findViewById(android.R.id.content);
        while(!ViewCompat.isLaidOut(rootView));
        mBottomLayoutExtras = rootView.findViewById(R.id.bottomLayoutExtras);
        mTopLayout = rootView.findViewById(R.id.topLayout);
        mBottomLayoutLives = rootView.findViewById(R.id.bottomLayoutLives);
    }

    /**
     * Force le redessinement du plateau de jeu par invalidation
     */
    public void invalidateGameBoard() {
        mGameBoardView.postInvalidate();
    }

    /**
     * Met à jour le score des vues du conteneur
     * @param score le nouveau score
     */
    public void updateScore(final int score) {
        final RelativeLayout topLayout = mTopLayout;
        mLifeScore += score;
        topLayout.post(new Runnable() {
            @Override
            public void run() {
                TextView textViewHighScoreValue = topLayout.findViewById(R.id.valueHighScore);
                TextView textView1UPValue = topLayout.findViewById(R.id.value1UP);
                textViewHighScoreValue.setText(String.format("%d", score));
                textView1UPValue.setText(String.format("%d", score));
            }
        });
    }

    /**
     * Met à jour les vies du joueur dans les vues du conteneur
     * @param player le personnage joueur
     */
    public void updatePlayerLives(Player player) {
        final int lives = player.getLives();
        final LinearLayout bottomLayoutLives = mBottomLayoutLives;

        if(mLifeScore > 10000) {
            mLifeScore %= 10000;
            player.addLive();
        }

        bottomLayoutLives.post(new Runnable() {
            @Override
            public void run() {
                ImageView pacmanLife1 = bottomLayoutLives.findViewById(R.id.pacmanLife1);
                ImageView pacmanLife2 = bottomLayoutLives.findViewById(R.id.pacmanLife2);
                ImageView pacmanLife3 = bottomLayoutLives.findViewById(R.id.pacmanLife3);
                pacmanLife1.setVisibility(VISIBLE);
                pacmanLife2.setVisibility(VISIBLE);
                pacmanLife3.setVisibility(VISIBLE);
                switch(lives) {
                    case 0:
                        pacmanLife1.setVisibility(INVISIBLE);
                    case 1:
                        pacmanLife2.setVisibility(INVISIBLE);
                    case 2:
                        pacmanLife3.setVisibility(INVISIBLE);
                    default:
                        break;
                }
            }
        });
    }

    /**
     * Met à jour les bonus dans les vues du conteneur
     * @param level l'indice du niveau courant
     */
    public void updateExtras(final int level) {
        final LinearLayout bottomLayoutExtras = mBottomLayoutExtras;
        bottomLayoutExtras.post(new Runnable() {
            @Override
            public void run() {
                ImageView extra1 = bottomLayoutExtras.findViewById(R.id.extra1);
                ImageView extra2 = bottomLayoutExtras.findViewById(R.id.extra2);
                ImageView extra3 = bottomLayoutExtras.findViewById(R.id.extra3);
                ImageView extra4 = bottomLayoutExtras.findViewById(R.id.extra4);
                ImageView extra5 = bottomLayoutExtras.findViewById(R.id.extra5);
                ImageView extra6 = bottomLayoutExtras.findViewById(R.id.extra6);
                ImageView extra7 = bottomLayoutExtras.findViewById(R.id.extra7);
                ImageView extra8 = bottomLayoutExtras.findViewById(R.id.extra8);
                extra1.setVisibility(INVISIBLE);
                extra2.setVisibility(INVISIBLE);
                extra3.setVisibility(INVISIBLE);
                extra4.setVisibility(INVISIBLE);
                extra5.setVisibility(INVISIBLE);
                extra6.setVisibility(INVISIBLE);
                extra7.setVisibility(INVISIBLE);
                extra8.setVisibility(INVISIBLE);
                switch(level) {
                    case 1:
                        extra1.setVisibility(VISIBLE);
                        break;
                    case 2:
                        extra2.setVisibility(VISIBLE);
                        break;
                    case 3:
                    case 4:
                        extra3.setVisibility(VISIBLE);
                        break;
                    case 5:
                    case 6:
                        extra4.setVisibility(VISIBLE);
                        break;
                    case 7:
                    case 8:
                        extra5.setVisibility(VISIBLE);
                        break;
                    case 9:
                    case 10:
                        extra6.setVisibility(VISIBLE);
                        break;
                    case 11:
                    case 12:
                        extra7.setVisibility(VISIBLE);
                        break;
                    case 13:
                    default:
                        extra8.setVisibility(VISIBLE);
                        break;
                }
            }
        });
    }

    /**
     * Identifie et déclenche la fin d'une partie
     * @param player le personnage joueur
     */
    public void checkGameOver(Player player) {
        if(player.getLives() > 0 || mGameEnded) return;
        mGameEnded = true;
        Intent intent1 = new Intent(mGameActivity, GameOverActivity.class);
        mGameActivity.startActivity(intent1);
    }
}

package emptyfield.thefearlessglutton.Characters;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import emptyfield.thefearlessglutton.Activities.R;
import emptyfield.thefearlessglutton.Configurations.GameConfig;

/**
 * Une fabrique de personnages
 */
public class CharacterFactory {
    private GameConfig mGameConfig;
    private Bitmap mPlayerSkin, mFearSkin, mBlinkySkin, mPinkySkin, mInkySkin, mClydeSkin;

    /**
     * Construit une fabrique de personnages
     * @param resources le paramètre resources
     * @param gameConfig le paramétrage de jeu
     */
    public CharacterFactory(Resources resources, GameConfig gameConfig) {
        mGameConfig = gameConfig;
        mPlayerSkin = BitmapFactory.decodeResource(resources, R.drawable.pac_man);
        mFearSkin = BitmapFactory.decodeResource(resources, R.drawable.ghost_chase);
        mBlinkySkin = BitmapFactory.decodeResource(resources, R.drawable.ghost_red);
        mPinkySkin = BitmapFactory.decodeResource(resources, R.drawable.ghost_pink);
        mInkySkin = BitmapFactory.decodeResource(resources, R.drawable.ghost_blue);
        mClydeSkin = BitmapFactory.decodeResource(resources, R.drawable.ghost_orange);
    }

    /**
     * Construit un personnage joueur
     * @return un personnage joueur
     */
    public Player getPlayer() {
        return new Player(mGameConfig.getLocationPlayer(), mPlayerSkin);
    }

    /**
     * Construit un fantôme de type Blinky
     * @return un fantôme de type Blinky
     */
    public Blinky getBlinky() {
        return new Blinky(mGameConfig.getLocationBlinky(), mBlinkySkin, mFearSkin);
    }

    /**
     * Construit un fantôme de type Pinky
     * @return un fantôme de type Pinky
     */
    public Pinky getPinky() {
        return new Pinky(mGameConfig.getLocationPinky(), mPinkySkin, mFearSkin);
    }

    /**
     * Construit un fantôme de type Inky
     * @return un fantôme de type Inky
     */
    public Inky getInky() {
        return new Inky(mGameConfig.getLocationInky(), mInkySkin, mFearSkin);
    }

    /**
     * Construit un fantôme de type Clyde
     * @return un fantôme de type Clyde
     */
    public Clyde getClyde() {
        return new Clyde(mGameConfig.getLocationClyde(), mClydeSkin, mFearSkin);
    }
}

package emptyfield.thefearlessglutton.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * L'activité hébergeant le menu de chargement des sauvegardes
 */
public class LoadSaveActivity extends AppCompatActivity  {
    private ListView listViewSaveData;
    private ArrayList<Save> mSaveList;

    /**
     * La méthode appelée lors de la création de l'activité
     * @param savedInstanceState le paramètre savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_save);

        listViewSaveData = findViewById(R.id.listViewSaveData);

        // récupère la liste des sauvegardes
        mSaveList = getSaves();
        // définit l'adaptateur pour la vue listViewSaveData
        final SaveAdapter adapter = new SaveAdapter(LoadSaveActivity.this, mSaveList);
        listViewSaveData.setAdapter(adapter);
    }

    /**
     * Efface une sauvegarde de la liste des sauvegardes
     * @param save une sauvegarde à supprimer
     */
    public void removeSave(Save save) {
        // récupère le rang associé à la sauvegarde à supprimer
        int rank = save.getRank();
        // efface la sauvegarde de la liste des sauvegardes
        mSaveList.remove(save);
        // reconstruit la liste des sauvegardes
        Set<String> saves = new TreeSet<>();
        for(Save s : mSaveList) {
            if(s.getRank() > rank) s.setRank(s.getRank()-1);
            saves.add(s.getNickname()+"\n"+s.getDate());
        }
        // redéfinit la liste des sauvegardes
        SharedPreferences settings = getSharedPreferences("GameLists",0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putStringSet("savedata", saves);
        editor.apply();
    }

    /**
     * Récupère la liste ordonnées des sauvegardes
     * @return la liste ordonnées des sauvegardes
     */
    private ArrayList<Save> getSaves() {
        // récupère la liste des sauvegardes
        SharedPreferences settings = getSharedPreferences("GameLists",0);
        Set<String> savedata = settings.getStringSet("savedata", new TreeSet<String>());
        // réordonne les éléments de la liste des sauvegardes par ordre décroissant des dates
        SortedSet<String> orderedSaves = new TreeSet<>(new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                Scanner scanner1 = new Scanner(s1);
                Scanner scanner2 = new Scanner(s2);
                String name1 = scanner1.nextLine();
                String name2 = scanner2.nextLine();
                String date1 = scanner1.nextLine();
                String date2 = scanner2.nextLine();
                scanner1.close();
                scanner2.close();
                return -1*date1.compareTo(date2);
            }
        });
        orderedSaves.addAll(savedata);
        // construit la liste ordonnées des sauvegardes
        ArrayList<Save> saves = new ArrayList<>();
        int rank = 1;
        for(String string : orderedSaves) {
            Scanner scanner = new Scanner(string);
            String name = scanner.nextLine();
            String date = scanner.nextLine();
            scanner.close();
            saves.add(new Save(rank++, name, date));
        }
        return saves;
    }

    /**
     * Une sauvegarde en tant qu'élément d'une vue ListView
     */
    private class Save {
        private int mRank;
        private String mNickname;
        private String mDate;

        /**
         * Construit une sauvegarde pour une vue ListView
         * @param rank le rang associé à la sauvegarde
         * @param nickname le pseudo d'un joueur
         * @param date la date d'enregistrement
         */
        public Save(int rank, String nickname, String date) {
            mRank = rank;
            mNickname = nickname;
            mDate = date;
        }

        /**
         * Renvoie le rang
         * @return le rang
         */
        public int getRank() {
            return mRank;
        }

        /**
         * Définit le rang
         * @param rank le rang
         */
        public void setRank(int rank) {
            mRank = rank;
        }

        /**
         * Renvoie le pseudo
         * @return le pseudo
         */
        public String getNickname() {
            return mNickname;
        }

        /**
         * Définit le pseudo
         * @param nickname le pseudo
         */
        public void setNickname(String nickname) {
            mNickname = nickname;
        }

        /**
         * Récupère la date
         * @return la date
         */
        public String getDate() {
            return mDate;
        }

        /**
         * Définit la date
         * @param date la date
         */
        public void setDate(String date) {
            mDate = date;
        }
    }

    /**
     * Un adaptateur pour les sauvegardes de la ListView
     */
    private class SaveAdapter extends ArrayAdapter<Save> {

        /**
         * Construit un adaptateur pour les sauvegardes de la ListView
         * @param context le paramètre context
         * @param saves la liste des sauvegardes
         */
        public SaveAdapter(Context context, ArrayList<Save> saves) {
            super(context, 0, saves);
        }

        /**
         * Récupère la vue à une position donnée
         * @param position le paramètre position
         * @param convertView le paramètre convertView
         * @param parent le paramètre parent
         * @return une vue
         */
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            if(convertView == null){
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.row_savedata,parent, false);
            }

            // mémorise le contenu de la vue
            SaveViewHolder viewHolder = (SaveViewHolder) convertView.getTag();
            if(viewHolder == null){
                viewHolder = new SaveViewHolder();
                viewHolder.rank = convertView.findViewById(R.id.rank);
                viewHolder.nickname = convertView.findViewById(R.id.nickname);
                viewHolder.date = convertView.findViewById(R.id.date);
                viewHolder.erase = convertView.findViewById(R.id.erase);
                convertView.setTag(viewHolder);
            }

            // récupère la sauvegarde à une position donnée
            final Save save = getItem(position);

            // place un écouteur d'évènement sur le bouton effacer
            viewHolder.erase.setOnClickListener(new View.OnClickListener() {
                /**
                 * La méthode appelée lors d'un clic sur un bouton
                 * @param view le paramètre view
                 */
                @Override
                public void onClick(View view) {
                    switch (view.getId()) {
                        case R.id.erase:
                            remove(save);
                            LoadSaveActivity.this.removeSave(save);
                            break;
                        default:
                            break;
                    }
                }
            });

            // met à jour le contenu de la vue
            viewHolder.rank.setText(""+save.getRank());
            viewHolder.nickname.setText(save.getNickname());
            viewHolder.date.setText(save.getDate());

            // place un écouteur d'évènement sur la vue
            convertView.setOnClickListener(new View.OnClickListener() {
                /**
                 * La méthode appelée lors d'un clic sur un bouton
                 * @param view le paramètre view
                 */
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(LoadSaveActivity.this, GameActivity.class);
                    intent.putExtra("nickname", save.getNickname());
                    LoadSaveActivity.this.startActivity(intent);
                }
            });

            return convertView;
        }

        /**
         * Une structure pour rassembler les vues associées à la sauvegarde
         */
        private class SaveViewHolder {
            public TextView rank;
            public TextView nickname;
            public TextView date;
            public Button erase;
        }
    }
}


package emptyfield.thefearlessglutton.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import emptyfield.thefearlessglutton.Core.GameBoardView;

/**
 * L'activité hébergeant l'interface de jeu
 */
public class GameActivity extends AppCompatActivity implements View.OnClickListener {
    private GameBoardView gameBoardView;
    private Button buttonPause;

    /**
     * La méthode appelée lors de la création de l'activité
     * @param savedInstanceState le paramètre savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        gameBoardView = findViewById(R.id.gameBoard);
        buttonPause = findViewById(R.id.buttonPause);

        buttonPause.setOnClickListener(this);
    }

    /**
     * La méthode appelée lors du démarrage de l'activité
     */
    @Override
    protected void onStart() {
        super.onStart();
        // démarre le moteur de jeu
        gameBoardView.startEngine();
    }

    /**
     * La méthode appelée lors de l'arrêt de l'activité
     */
    @Override
    protected void onStop() {
        super.onStop();
        // interrompt le moteur de jeu
        gameBoardView.stopEngine();
    }

    /**
     * La méthode appelée lors d'un clic sur un bouton
     * @param view le paramètre view
     */
    @Override
    public void onClick(View view) {
        // récupère le paramètre nickname
        Bundle extras = getIntent().getExtras();
        String nickname = extras == null ? null : extras.getString("nickname");
        switch (view.getId()) {
            case R.id.buttonPause:
                Intent intent1 = new Intent(GameActivity.this, PauseActivity.class);
                // démarre l'activité PauseActivity avec le paramètre nickname
                intent1.putExtra("nickname",nickname);
                startActivity(intent1);
                break;
        }
    }
}
package emptyfield.thefearlessglutton.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * L'activité hébergeant le menu pause
 */
public class PauseActivity extends AppCompatActivity implements View.OnClickListener {
    private Button buttonResume, buttonSave, buttonMainMenu;

    /**
     * La méthode appelée lors de la création de l'activité
     * @param savedInstanceState le paramètre savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pause);

        buttonResume = findViewById(R.id.buttonResume);
        buttonSave = findViewById(R.id.buttonSave);
        buttonMainMenu = findViewById(R.id.buttonMainMenu);

        buttonResume.setOnClickListener(this);
        buttonSave.setOnClickListener(this);
        buttonMainMenu.setOnClickListener(this);
    }

    /**
     * La méthode appelée lors d'un clic sur un bouton
     * @param view le paramètre view
     */
    @Override
    public void onClick(View view) {
        // récupère le paramètre nickname
        Bundle extras = getIntent().getExtras();
        String nickname = extras == null ? null : extras.getString("nickname");
        switch (view.getId()) {
            case R.id.buttonResume:
                Intent intent1 = new Intent(PauseActivity.this, GameActivity.class);
                // démarre l'activité GameActivity avec le paramètre nickname
                intent1.putExtra("nickname",nickname);
                startActivity(intent1);
                break;
            case R.id.buttonSave:
                Intent intent2 = new Intent(PauseActivity.this, SaveActivity.class);
                // démarre l'activité SaveActivity avec le paramètre nickname
                intent2.putExtra("nickname",nickname);
                startActivity(intent2);
                break;
            case R.id.buttonMainMenu:
                Intent intent3 = new Intent(PauseActivity.this, MainMenuActivity.class);
                // démarre l'activité MainMenuActivity
                startActivity(intent3);
                break;
        }
    }
}

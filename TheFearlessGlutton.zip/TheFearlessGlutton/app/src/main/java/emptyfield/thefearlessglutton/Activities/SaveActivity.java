package emptyfield.thefearlessglutton.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * L'activité hébergeant le menu de sauvegarde
 */
public class SaveActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher {
    private Button buttonSave, buttonBack;
    private EditText editTextUsername;
    private TextView textSaved;
    private String mNickname;

    /**
     * La méthode appelée lors de la création de l'activité
     * @param savedInstanceState le paramètre savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save);

        buttonSave = findViewById(R.id.buttonSave);
        buttonBack = findViewById(R.id.buttonBack);
        editTextUsername = findViewById(R.id.editTextUsername);
        textSaved = findViewById(R.id.textSaved);

        buttonSave.setOnClickListener(this);
        buttonBack.setOnClickListener(this);
        editTextUsername.addTextChangedListener(this);
    }

    /**
     * Génère une sauvegarde
     */
    @SuppressWarnings("unchecked")
    private void save() {
        // récupère le contexte courant
        Bundle extras = getIntent().getExtras();
        String nickname = extras == null ? null : extras.getString("nickname");
        if(nickname == null) nickname = "";
        SharedPreferences settings1 = getSharedPreferences("GameContext\n"+nickname, 0);
        // récupère le contexte de destination
        SharedPreferences settings2 = getSharedPreferences("GameContext\n"+mNickname, 0);
        // duplique le contexte courant dans le contexte de destination
        SharedPreferences.Editor editor = settings2.edit();
        for(Map.Entry<String,?> entry : settings1.getAll().entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (value instanceof String) {
                editor.putString(key, (String) value);
            } else if (value instanceof Set) {
                editor.putStringSet(key, (Set<String>) value);
            } else if (value instanceof Integer) {
                editor.putInt(key, (Integer) value);
            } else if (value instanceof Long) {
                editor.putLong(key, (Long) value);
            } else if (value instanceof Float) {
                editor.putFloat(key, (Float) value);
            } else if (value instanceof Boolean) {
                editor.putBoolean(key, (Boolean) value);
            }
        }
        editor.apply();
        // récupère la liste des sauvegardes
        SharedPreferences settings3 = getSharedPreferences("GameLists", 0);
        Set<String> savedata = new TreeSet<>(settings3.getStringSet("savedata", new TreeSet<String>()));
        // récupère la date courante
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Calendar calendar = Calendar.getInstance();
        // ajoute une sauvegarde à la liste au format 'nickname\ndate'
        savedata.add(mNickname+"\n"+sdf.format(calendar.getTime()));
        // redéfinit la liste des sauvegardes
        editor = settings3.edit();
        editor.putStringSet("savedata", savedata);
        editor.apply();
    }

    /**
     * La méthode appelée lors d'un clic sur un bouton
     * @param view le paramètre view
     */
    @Override
    public void onClick(View view) {
        // récupère le paramètre nickname
        Bundle extras = getIntent().getExtras();
        String nickname = extras == null ? null : extras.getString("nickname");
        switch (view.getId()) {
            case R.id.buttonSave:
                // sauvegarde la partie
                save();
                // confirme la sauvegarde de la partie
                textSaved.setVisibility(View.VISIBLE);
                break;
            case R.id.buttonBack:
                Intent intent1 = new Intent(SaveActivity.this, PauseActivity.class);
                // démarre l'activité PauseActivity avec le paramètre nickname
                intent1.putExtra("nickname", nickname);
                startActivity(intent1);
                break;
        }
    }

    /**
     * La méthode appelée avant la modification d'une entrée texte
     * @param s le paramètre s
     * @param start le paramètre start
     * @param count le paramètre count
     * @param after le paramètre after
     */
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

    /**
     * La méthode appelée lors de la modification d'une entrée texte
     * @param s le paramètre s
     * @param start le paramètre start
     * @param before le paramètre before
     * @param count le paramètre count
     */
    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        mNickname = s.toString();
    }

    /**
     * La méthode appelée après la modification d'une entrée texte
     * @param s le paramètre s
     */
    @Override
    public void afterTextChanged(Editable s) { }
}

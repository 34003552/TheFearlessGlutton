package emptyfield.thefearlessglutton.Activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * L'activité hébergeant l'affichage des scores
 */
public class ShowScoresActivity extends AppCompatActivity {
    private ListView listViewShowScores;
    private ArrayList<Score> mScoreList;

    /**
     * La méthode appelée lors de la création de l'activité
     * @param savedInstanceState le paramètre savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_scores);

        listViewShowScores = findViewById(R.id.listViewShowScores);

        // construit la liste des scores
        mScoreList = buildList();
        // définit l'adaptateur pour la liste listViewShowScores
        final ScoreAdapter adapter = new ScoreAdapter(ShowScoresActivity.this, mScoreList);
        listViewShowScores.setAdapter(adapter);
    }

    /**
     * Construit la liste ordonnée décroissante des scores
     * @return la liste ordonnée décroissante des scores
     */
    private ArrayList<Score> buildList() {
        // récupère la liste des scores
        SharedPreferences settings = getSharedPreferences("GameLists",0);
        Set<String> scores = settings.getStringSet("scores", new TreeSet<String>());
        // réordonne la liste des scores
        SortedSet<String> orderedScores = new TreeSet<>(new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                Scanner scanner1 = new Scanner(s1);
                Scanner scanner2 = new Scanner(s2);
                Integer score1 = scanner1.nextInt();
                Integer score2 = scanner2.nextInt();
                scanner1.skip("\n");
                scanner2.skip("\n");
                String username1 = scanner1.nextLine();
                String username2 = scanner2.nextLine();
                scanner1.close();
                scanner2.close();
                if(score1.equals(score2)) {
                    return username1.compareTo(username2);
                }
                return -1*score1.compareTo(score2);
            }
        });
        orderedScores.addAll(scores);
        // construit la liste des scores pour la vue ListView
        ArrayList<Score> orderedScoresArray = new ArrayList<>();
        int rank = 1;
        for(String score : orderedScores) {
            Scanner scanner = new Scanner(score);
            String score1 = scanner.nextLine();
            String name = scanner.nextLine();
            String date = scanner.nextLine();
            scanner.close();
            orderedScoresArray.add(new Score(rank++, score1, name, date));
        }
        return orderedScoresArray;
    }

    /**
     * Efface un score
     * @param score le score à effacer
     */
    private void removeScore(Score score) {
        // récupère le rang associé au score
        int rank = score.getRank();
        // efface le score de la liste des scores
        mScoreList.remove(score);
        // reconstruit la liste des scores
        Set<String> scores = new TreeSet<>();
        for(Score t : mScoreList) {
            if(t.getRank() > rank) t.setRank(t.getRank()-1);
            scores.add(t.getScore()+"\n"+t.getNickname()+"\n"+t.getDate());
        }
        // redéfinit la liste des scores
        SharedPreferences settings = getSharedPreferences("GameLists",0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putStringSet("scores", scores);
        editor.apply();
    }

    /**
     * Un score pour une vue ListView
     */
    private class Score {
        private int mRank;
        private String mScore;
        private String mNickname;
        private String mDate;

        /**
         * Construit un score pour une vue ListView
         * @param rank le rang
         * @param score le score
         * @param nickname le pseudo
         * @param date la date
         */
        public Score(int rank, String score, String nickname, String date) {
            mRank = rank;
            mScore = score;
            mNickname = nickname;
            mDate = date;
        }

        /**
         * Récupère le rang
         * @return le rang
         */
        public int getRank() {
            return mRank;
        }

        /**
         * Définit le rang
         * @param rank le rang
         */
        public void setRank(int rank) {
            mRank = rank;
        }

        /**
         * Récupère le score
         * @return le score
         */
        public String getScore() {
            return mScore;
        }

        /**
         * Définit le score
         * @param score le score
         */
        public void setScore(String score) {
            mScore = score;
        }

        /**
         * Récupère le pseudo
         * @return le pseudo
         */
        public String getNickname() {
            return mNickname;
        }

        /**
         * Définit le pseudo
         * @param nickname le pseudo
         */
        public void setNickname(String nickname) {
            mNickname = nickname;
        }

        /**
         * Récupère la date
         * @return la date
         */
        public String getDate() {
            return mDate;
        }

        /**
         * Définit la date
         * @param date la date
         */
        public void setDate(String date) {
            mDate = date;
        }
    }

    /**
     * Un adaptateur de score pour une vue ListView
     */
    private class ScoreAdapter extends ArrayAdapter<Score> {

        /**
         * Construit un adaptateur de score pour une vue ListView
         * @param context le paramètre context
         * @param scores le paramètre scores
         */
        public ScoreAdapter(Context context, ArrayList<Score> scores) {
            super(context, 0, scores);
        }

        /**
         * Récupère la vue à une position donnée
         * @param position le paramètre position
         * @param convertView le paramètre convertView
         * @param parent le paramètre parent
         * @return une vue
         */
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            if(convertView == null){
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.row_score,parent, false);
            }

            // mémorise le contenu de la vue
            ScoreViewHolder viewHolder = (ScoreViewHolder) convertView.getTag();
            if(viewHolder == null){
                viewHolder = new ScoreViewHolder();
                viewHolder.rank = convertView.findViewById(R.id.rank);
                viewHolder.score = convertView.findViewById(R.id.score);
                viewHolder.nickname = convertView.findViewById(R.id.nickname);
                viewHolder.date = convertView.findViewById(R.id.date);
                viewHolder.erase = convertView.findViewById(R.id.erase);
                convertView.setTag(viewHolder);
            }

            // récupère le score à une position donnée
            final Score score = getItem(position);

            // place un écouteur d'évènement sur le bouton effacer
            viewHolder.erase.setOnClickListener(new View.OnClickListener() {
                /**
                 * La méthode appelée lors d'un clic sur un bouton
                 * @param view le paramètre view
                 */
                @Override
                public void onClick(View view) {
                    switch (view.getId()) {
                        case R.id.erase:
                            remove(score);
                            ShowScoresActivity.this.removeScore(score);
                            break;
                        default:
                            break;
                    }
                }
            });

            // met à jour le contenu de la vue
            viewHolder.rank.setText(""+score.getRank());
            viewHolder.score.setText(score.getScore());
            viewHolder.nickname.setText(score.getNickname());
            viewHolder.date.setText(score.getDate());

            return convertView;
        }

        /**
         * Une structure pour rassembler les vues associées au score
         */
        private class ScoreViewHolder{
            public TextView rank;
            public TextView score;
            public TextView nickname;
            public TextView date;
            public Button erase;
        }
    }
}


package emptyfield.thefearlessglutton.Core;

import android.graphics.Canvas;

import java.util.ArrayList;
import java.util.HashMap;

import emptyfield.thefearlessglutton.Configurations.GameConfig;

/**
 * Une grille de jeu
 */
public class Grid {
    private int mWidth;
    private int mHeight;
    private float mBoxWidth;
    private float mBoxHeight;
    private int centerX;
    private int centerY;
    private float canvasWidth;
    private float canvasHeight;
    private Labyrinth mLabyrinth;
    private ArrayList<GridPoint> mAccessiblePoints;

    /**
     * Construit une grille de jeu
     * @param gameConfig la configuration de jeu
     */
    public Grid(GameConfig gameConfig) {
        mLabyrinth = new Labyrinth(gameConfig);
        mWidth = gameConfig.getGridWidth();
        mHeight = gameConfig.getGridHeight();
        findAccessiblePoints(gameConfig.getLocationPlayer());
    }

    /**
     * Récupère la largeur de la grille
     * @return la largeur de la grille
     */
    public int getWidth() {
        return mWidth;
    }

    /**
     * Récupère la hauteur de la grille
     * @return la hauteur de la grille
     */
    public int getHeight() {
        return mHeight;
    }

    /**
     * Récupère la largeur d'une case
     * @return la largeur d'une case
     */
    public float getBoxWidth() {
        return mBoxWidth;
    }

    /**
     * Récupère la hauteur d'une case
     * @return la hauteur d'une case
     */
    public float getBoxHeight() {
        return mBoxHeight;
    }

    /**
     * Convertit un point en point de la grille
     * @param x la coordonnée horizontale d'un point
     * @param y la coordonnée verticale d'un point
     * @return un point de la grille
     */
    public GridPoint toGridPoint(float x, float y) {
        int nx = (int) Math.floor((x - mBoxWidth / 2) / canvasWidth * mWidth);
        int ny = (int) Math.floor((y - mBoxHeight / 2) / canvasHeight * mHeight);
        return new GridPoint(nx, ny);
    }

    /**
     * Récupère la coordonnée horizontale d'un point de la grille
     * @param location une position dans la grille
     * @return la coordonnée horizontale d'un point de la grille
     */
    public float getOnScreenX(GridPoint location) {
        return centerX - canvasWidth / 2 + mBoxWidth / 2 + location.getX() * mBoxWidth;
    }

    /**
     * Récupère la coordonnée verticale d'un point de la grille
     * @param location une position dans la grille
     * @return la coordonnée verticale d'un point de la grille
     */
    public float getOnScreenY(GridPoint location) {
        return centerY - canvasHeight / 2 + mBoxHeight / 2 + location.getY() * mBoxHeight;
    }

    /**
     * Récupère le voisinage d'un point
     * @param gridPoint un point de la grille
     * @return le voisinage d'un point
     */
    public ArrayList<GridPoint> getPointNeighborhood(GridPoint gridPoint) {
        ArrayList<GridPoint> gridPoints = new ArrayList<>();

        // Le voisin du dessus
        if (!mLabyrinth.hasHorizontalWallAt(gridPoint.getX(), gridPoint.getY())) {
            gridPoints.add(new GridPoint(gridPoint.getX(), (gridPoint.getY() + mHeight - 1) % mHeight));
        }
        // Le voisin du dessous
        if (!mLabyrinth.hasHorizontalWallAt(gridPoint.getX(), gridPoint.getY() + 1)) {
            gridPoints.add(new GridPoint(gridPoint.getX(), (gridPoint.getY() + 1) % mHeight));
        }
        // Le voisin de gauche
        if (!mLabyrinth.hasVerticalWallAt(gridPoint.getX(), gridPoint.getY())) {
            gridPoints.add(new GridPoint((gridPoint.getX() + mWidth - 1) % mWidth, gridPoint.getY()));
        }
        // Le voisin de droite
        if (!mLabyrinth.hasVerticalWallAt(gridPoint.getX() + 1, gridPoint.getY())) {
            gridPoints.add(new GridPoint((gridPoint.getX() + 1) % mWidth, gridPoint.getY()));
        }

        return gridPoints;
    }

    /**
     * Récupère un point accessible aléatoire dans la grille
     * @return un point aléatoire de la grille
     */
    public GridPoint getRandomAccessiblePoint() {
        return mAccessiblePoints.get((int) (Math.random() * mAccessiblePoints.size()));
    }

    /**
     * Récupère la liste des points accessibles de la grille
     * @return la liste des points accessibles de la grille
     */
    public ArrayList<GridPoint> getAccessiblePoints() {
        return mAccessiblePoints;
    }

    /**
     * Identifie les points accessibles de la grille
     */
    private void findAccessiblePoints(GridPoint gridPoint) {
        ArrayList<GridPoint> gridPoints = new ArrayList<>();
        gridPoints.add(gridPoint);

        for (int i = 0; i < gridPoints.size(); i++) {
            ArrayList<GridPoint> neighbors = getPointNeighborhood(gridPoints.get(i));
            for (GridPoint neighbor : neighbors)
                if (!gridPoints.contains(neighbor)) gridPoints.add(neighbor);
        }

        mAccessiblePoints = gridPoints;
    }

    /**
     * Une implémentation de l'algorithme de Dijkstra
     * @param pointA un point de la grille
     * @param pointB un point de la grille
     * @return un chemin entre les deux points ou un chemin vide s'il n'en existe pas
     */
    public ArrayList<GridPoint> Dijkstra(GridPoint pointA, GridPoint pointB) {
        int maxdist = mWidth * mHeight;
        HashMap<GridPoint, Integer> distances = new HashMap<>();
        ArrayList<GridPoint> nodes = new ArrayList<>(mAccessiblePoints);
        for (GridPoint gridPoint : nodes) {
            distances.put(gridPoint, maxdist);
        }
        distances.put(pointA, 0);

        HashMap<GridPoint, GridPoint> prevnodes = new HashMap<>();
        while (nodes.size() != 0) {
            int mini = maxdist;
            GridPoint rnode = null;
            for (GridPoint node : nodes) {
                if (distances.get(node) < mini) {
                    mini = distances.get(node);
                    rnode = node;
                }
            }
            if (!nodes.contains(rnode)) break;
            nodes.remove(rnode);

            ArrayList<GridPoint> neighnodes = getPointNeighborhood(rnode);
            for (GridPoint snode : neighnodes) {
                if (distances.get(snode) > distances.get(rnode) + 1) {
                    distances.put(snode, distances.get(rnode) + 1);
                    prevnodes.put(snode, rnode);
                }
            }
        }
        ArrayList<GridPoint> path = new ArrayList<>();
        GridPoint s = pointB;
        while (!pointA.equals(s)) {
            path.add(0, s);
            if (!prevnodes.containsKey(s)) {
                path.clear();
                return path;
            }
            s = prevnodes.get(s);
        }
        return path;
    }

    /**
     * Dessine la grille
     * @param canvas le paramètre canvas
     * @param x la coordonnée horizontale du centre de la zone de dessin
     * @param y la coordonnée vertciale du centre de la zone de dessin
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    public void draw(Canvas canvas, int x, int y, int width, int height) {
        mLabyrinth.draw(canvas, x, y, width, height);
        mBoxWidth = width / mWidth;
        mBoxHeight = height / mHeight;
        centerX = x;
        centerY = y;
        canvasWidth = width;
        canvasHeight = height;
    }
}

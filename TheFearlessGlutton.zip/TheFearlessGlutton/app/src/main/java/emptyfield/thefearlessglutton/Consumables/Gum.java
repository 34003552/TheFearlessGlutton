package emptyfield.thefearlessglutton.Consumables;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Une pac-gomme définie comme étant un consommable
 */
public class Gum extends Consumable {

    /**
     * Construit une pac-gomme
     * @param location la position de la pac-gomme
     */
    public Gum(GridPoint location) {
        super(location, null, "gum", 10);
    }

    /**
     * Dessine la pac-gomme
     * @param canvas le paramètre canvas
     * @param x la position centrale horizontale de la zone de dessin
     * @param y la position centrale verticale de la zone de dessin
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    @Override
    public void draw(Canvas canvas, int x, int y, int width, int height) {
        Paint p = new Paint();
        p.setColor(Color.WHITE);
        canvas.drawOval(new RectF(x - width / 8, y - height / 8, x + width / 8, y + height / 8), p);
    }
}

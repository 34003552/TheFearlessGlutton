package emptyfield.thefearlessglutton.Characters;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

import emptyfield.thefearlessglutton.Core.Grid;
import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Un fantôme de type Clyde
 */
public class Clyde extends Ghost {

    /**
     * Construit Clyde
     * @param location la position initiale du fantôme
     * @param skin l'apparence associée au fantôme
     * @param fearSkin l'apparence associée au fantôme quand il a peur
     */
    public Clyde(GridPoint location, Bitmap skin, Bitmap fearSkin) {
        super(location, skin, fearSkin);
    }

    /**
     * Met à jour le chemin que doit suivre Clyde
     * @param grid la grille dans laquelle se trouvent les personnages
     * @param characters la liste des personnages
     */
    @Override
    public void updatePath(Grid grid, ConcurrentHashMap<String, Character> characters) {
        // un fantôme mort doit impérativement retourner à sa position initiale pour sa resurrection
        if(mDead && mLocation != mInitialLocation) return;

        Player player = (Player) characters.get("player");
        ArrayList<GridPoint> clydePath;
        ArrayList<GridPoint> tmpPath = grid.Dijkstra(mLocation, player.getLocation());
        if (tmpPath.size() < 8) {
            clydePath = grid.Dijkstra(mLocation, new GridPoint(0, grid.getHeight()));
        } else {
            tmpPath.addAll(player.getPath());
            clydePath = tmpPath;
        }
        setPath(clydePath);
    }
}

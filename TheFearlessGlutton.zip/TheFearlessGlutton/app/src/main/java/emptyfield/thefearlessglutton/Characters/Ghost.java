package emptyfield.thefearlessglutton.Characters;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

import java.util.concurrent.ConcurrentHashMap;

import emptyfield.thefearlessglutton.Core.Grid;
import emptyfield.thefearlessglutton.Core.GridPoint;

/**
 * Un fantôme modèle
 */
public abstract class Ghost extends Character {
    private boolean mFear;
    private Bitmap mFearSkin;

    /**
     * Construit un fantôme
     * @param location la position initiale du fantôme
     * @param skin l'apparence associée au fantôme
     * @param fearSkin l'apparence associée au fantôme quand il a peur
     */
    public Ghost(GridPoint location, Bitmap skin, Bitmap fearSkin) {
        super(location, skin);
        mFear = false;
        mFearSkin = fearSkin;
    }

    /**
     * Définit l'état de peur pour le fantôme
     * @param fear l'état de peur
     */
    public void setFearMode(boolean fear) {
        mFear = fear;
    }

    /**
     * Met à jour le chemin que doit suivre le fantôme
     * @param grid la grille dans laquelle se trouvent les personnages
     * @param characters la liste des personnages
     */
    public abstract void updatePath(Grid grid, ConcurrentHashMap<String, Character> characters);

    /**
     * Ressuscite le fantôme
     */
    @Override
    public void rebirth() {
        if(mLocation != mInitialLocation) return;
        super.rebirth();
    }

    /**
     * Dessine le fantôme
     * @param canvas le paramètre canvas
     * @param x la coordonnée centrale de la zone de dessin suivant l'axe horizontal
     * @param y la coordonnée centrale de la zone de dessin suivant l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    @Override
    public void draw(Canvas canvas, int x, int y, int width, int height) {
        Paint p = new Paint();
        if (!mDead) {
            canvas.drawBitmap(mFear ? mFearSkin : mSkin, null, new RectF(x - width / 2, y - height / 2, x + width / 2, y + height / 2), p);
        } else {
            p.setColor(Color.BLUE);
            canvas.drawOval(new RectF(x - width / 8, y - height / 8, x + width / 8, y + height / 8), p);
        }
    }
}
